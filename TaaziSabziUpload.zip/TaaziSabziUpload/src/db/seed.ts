import { db } from "@/db";
import { categories, products, users } from "@/db/schema";
import { count } from "drizzle-orm";

export const seedCategories = [
  { slug: "leafy", name: "Leafy Greens", nameHi: "पत्तेदार सब्ज़ियाँ", emoji: "🥬" },
  { slug: "root", name: "Root Vegetables", nameHi: "जड़ वाली सब्ज़ियाँ", emoji: "🥔" },
  { slug: "seasonal", name: "Seasonal", nameHi: "मौसमी", emoji: "🌽" },
  { slug: "organic", name: "Organic", nameHi: "ऑर्गेनिक", emoji: "🌱" },
  { slug: "exotic", name: "Exotic", nameHi: "विदेशी", emoji: "🥦" },
  { slug: "fruits", name: "Fruits", nameHi: "फल", emoji: "🍎" },
];

export const seedProducts = [
  { slug: "tamatar", name: "Tomato", nameHi: "टमाटर", variety: "Desi Hybrid", categorySlug: "seasonal", image: "/images/tomato.jpg", price: "30", wholesalePrice: "300", wholesaleMinQty: 25, unit: "kg", stock: 120, organic: false, seasonal: true, sold: 540, rating: "4.7", description: "Juicy red tomatoes picked fresh this morning from Khutpipariya farms." },
  { slug: "aalu", name: "Potato", nameHi: "आलू", variety: "Chipsona", categorySlug: "root", image: "/images/potato.jpg", price: "22", wholesalePrice: "18", wholesaleMinQty: 50, unit: "kg", stock: 400, organic: false, seasonal: false, sold: 980, rating: "4.6", description: "Clean, firm potatoes — perfect for sabzi, paratha and fries." },
  { slug: "bhindi", name: "Lady Finger (Bhindi)", nameHi: "भिंडी", variety: "Green Soft", categorySlug: "seasonal", image: "/images/bhindi.jpg", price: "45", wholesalePrice: "38", wholesaleMinQty: 20, unit: "kg", stock: 60, organic: true, seasonal: true, sold: 320, rating: "4.8", description: "Tender organic bhindi, no pesticides, harvested daily." },
  { slug: "phool-gobhi", name: "Cauliflower (Phool Gobhi)", nameHi: "फूल गोभी", variety: "Snowball", categorySlug: "seasonal", image: "/images/cauliflower.jpg", price: "35", wholesalePrice: "28", wholesaleMinQty: 30, unit: "piece", stock: 80, organic: false, seasonal: true, sold: 410, rating: "4.5", description: "Big white tight florets — ideal for gobhi aloo and pakoda." },
  { slug: "palak", name: "Spinach (Palak)", nameHi: "पालक", variety: "Desi", categorySlug: "leafy", image: "/images/spinach.jpg", price: "20", wholesalePrice: "15", wholesaleMinQty: 30, unit: "bunch", stock: 150, organic: true, seasonal: false, sold: 610, rating: "4.6", description: "Fresh green palak bunches, washed and ready to cook." },
  { slug: "shimla-mirch", name: "Capsicum (Shimla Mirch)", nameHi: "शिमला मिर्च", variety: "Green Bell", categorySlug: "exotic", image: "/images/capsicum.jpg", price: "60", wholesalePrice: "50", wholesaleMinQty: 20, unit: "kg", stock: 45, organic: false, seasonal: false, sold: 215, rating: "4.4", description: "Crunchy green capsicum for chilli paneer and salads." },
  { slug: "karela", name: "Bitter Gourd (Karela)", nameHi: "करेला", variety: "Long Green", categorySlug: "seasonal", image: "/images/karela.jpg", price: "40", wholesalePrice: "32", wholesaleMinQty: 20, unit: "kg", stock: 35, organic: true, seasonal: true, sold: 130, rating: "4.3", description: "Healthy organic karela directly from local farmers." },
  { slug: "pyaz", name: "Onion (Pyaz)", nameHi: "प्याज़", variety: "Nashik Red", categorySlug: "root", image: "/images/onion.jpg", price: "28", wholesalePrice: "22", wholesaleMinQty: 50, unit: "kg", stock: 300, organic: false, seasonal: false, sold: 870, rating: "4.5", description: "Red onions with long shelf life, sorted and graded." },
  { slug: "patta-gobhi", name: "Cabbage (Patta Gobhi)", nameHi: "पत्ता गोभी", variety: "Green Round", categorySlug: "leafy", image: "/images/cabbage.jpg", price: "25", wholesalePrice: "18", wholesaleMinQty: 30, unit: "piece", stock: 8, organic: false, seasonal: true, sold: 290, rating: "4.4", description: "Crisp cabbage heads for sabzi, salad and momos." },
];

export async function ensureSeeded() {
  const [{ value }] = await db.select({ value: count() }).from(products);
  if (Number(value) > 0) return;
  await db.insert(categories).values(seedCategories).onConflictDoNothing();
  await db
    .insert(products)
    .values(
      seedProducts.map((p) => ({
        ...p,
        freshnessDate: new Date().toISOString().slice(0, 10),
        sellerName: "TaaziSabzi Farm",
        sellerArea: "Khutpipariya, MP",
      }))
    )
    .onConflictDoNothing();
  await db
    .insert(users)
    .values([
      { name: "Admin", email: "admin@taazisabzi.in", phone: "6266093569", password: "admin123", role: "admin", verified: true, area: "Khutpipariya" },
      { name: "Demo Seller", email: "seller@taazisabzi.in", phone: "9999999999", password: "seller123", role: "seller", verified: true, area: "Khutpipariya" },
      { name: "Demo Buyer", email: "buyer@taazisabzi.in", phone: "8888888888", password: "buyer123", role: "buyer", verified: true, area: "Narsinghpur" },
    ])
    .onConflictDoNothing();
}
