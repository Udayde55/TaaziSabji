import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  numeric,
  jsonb,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  password: text("password").notNull(),
  role: text("role").notNull().default("buyer"), // buyer | seller | admin
  address: text("address"),
  area: text("area"),
  verified: boolean("verified").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  nameHi: text("name_hi").notNull(),
  emoji: text("emoji").notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  nameHi: text("name_hi").notNull(),
  variety: text("variety"),
  description: text("description"),
  categorySlug: text("category_slug").notNull(),
  image: text("image").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  wholesalePrice: numeric("wholesale_price", { precision: 10, scale: 2 }),
  wholesaleMinQty: integer("wholesale_min_qty"),
  unit: text("unit").notNull().default("kg"), // kg | piece | bunch | crate
  stock: integer("stock").notNull().default(0),
  organic: boolean("organic").notNull().default(false),
  seasonal: boolean("seasonal").notNull().default(false),
  freshnessDate: text("freshness_date"),
  sellerName: text("seller_name").notNull().default("TaaziSabzi Farm"),
  sellerArea: text("seller_area").notNull().default("Khutpipariya, MP"),
  rating: numeric("rating", { precision: 2, scale: 1 }).notNull().default("4.5"),
  sold: integer("sold").notNull().default(0),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  address: text("address").notNull(),
  area: text("area").notNull(),
  deliverySlot: text("delivery_slot").notNull(), // express10 | sameday | nextday
  paymentMethod: text("payment_method").notNull(), // upi | card | netbanking | cod | wallet
  paymentStatus: text("payment_status").notNull().default("pending"),
  status: text("status").notNull().default("placed"), // placed | accepted | packed | out_for_delivery | delivered | cancelled
  subtotal: numeric("subtotal", { precision: 10, scale: 2 }).notNull(),
  deliveryCharge: numeric("delivery_charge", { precision: 10, scale: 2 }).notNull(),
  discount: numeric("discount", { precision: 10, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  coupon: text("coupon"),
  notes: text("notes"),
  items: jsonb("items").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sellRequests = pgTable("sell_requests", {
  id: serial("id").primaryKey(),
  farmerName: text("farmer_name").notNull(),
  phone: text("phone").notNull(),
  village: text("village").notNull(),
  vegetable: text("vegetable").notNull(),
  quantity: text("quantity").notNull(),
  unit: text("unit").notNull(), // kg | crate | quintal
  expectedPrice: numeric("expected_price", { precision: 10, scale: 2 }).notNull(),
  organic: boolean("organic").notNull().default(false),
  notes: text("notes"),
  status: text("status").notNull().default("pending"), // pending | visit_scheduled | purchased | rejected
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  name: text("name").notNull(),
  rating: integer("rating").notNull(),
  comment: text("comment"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type SellRequest = typeof sellRequests.$inferSelect;
export type Category = typeof categories.$inferSelect;
