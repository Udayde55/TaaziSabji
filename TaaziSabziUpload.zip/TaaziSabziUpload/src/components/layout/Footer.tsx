import Link from "next/link";
import { Leaf, Mail, Phone, MapPin, MessageCircle } from "lucide-react";

export const CONTACT = {
  email: "uday38506@gmail.com",
  phone: "+91 6266093569",
  phoneRaw: "916266093569",
  place: "Khutpipariya, Madhya Pradesh, India",
};

export default function Footer() {
  return (
    <footer className="mt-12 border-t border-green-100 bg-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-green-700 text-white">
              <Leaf size={20} />
            </span>
            <span className="text-lg font-bold text-green-800">TaaziSabzi</span>
          </div>
          <p className="mt-3 text-sm text-gray-600">
            Taazi Sabzi Seedhe Farm Se. Farm-fresh vegetables from Khutpipariya farmers to your kitchen — buy, sell & grow together.
          </p>
        </div>
        <div>
          <h4 className="font-semibold text-gray-900">Quick Links</h4>
          <ul className="mt-3 space-y-2 text-sm text-gray-600">
            <li><Link href="/products" className="hover:text-green-700">All Vegetables</Link></li>
            <li><Link href="/sell" className="hover:text-green-700">Sell Your Sabzi (Kisaan)</Link></li>
            <li><Link href="/orders" className="hover:text-green-700">Track Order</Link></li>
            <li><Link href="/seller" className="hover:text-green-700">Seller Dashboard</Link></li>
            <li><Link href="/contact" className="hover:text-green-700">Contact Us</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold text-gray-900">Policies</h4>
          <ul className="mt-3 space-y-2 text-sm text-gray-600">
            <li><Link href="/contact#policy" className="hover:text-green-700">Freshness Guarantee</Link></li>
            <li><Link href="/contact#policy" className="hover:text-green-700">Return / Replacement</Link></li>
            <li><Link href="/contact#policy" className="hover:text-green-700">Secure Payments</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold text-gray-900">Contact Us / संपर्क</h4>
          <ul className="mt-3 space-y-2 text-sm text-gray-600">
            <li className="flex items-center gap-2"><Mail size={16} className="text-green-700" /><a href={`mailto:${CONTACT.email}`} className="hover:text-green-700">{CONTACT.email}</a></li>
            <li className="flex items-center gap-2"><Phone size={16} className="text-green-700" /><a href={`tel:${CONTACT.phone.replace(/\s/g, "")}`} className="hover:text-green-700">{CONTACT.phone}</a></li>
            <li className="flex items-center gap-2"><MessageCircle size={16} className="text-green-700" /><a href={`https://wa.me/${CONTACT.phoneRaw}`} target="_blank" rel="noreferrer" className="hover:text-green-700">WhatsApp Order</a></li>
            <li className="flex items-start gap-2"><MapPin size={16} className="mt-0.5 text-green-700" />{CONTACT.place}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-green-100 py-4 text-center text-xs text-gray-500">
        © {new Date().getFullYear()} TaaziSabzi · Made with 💚 in Madhya Pradesh
      </div>
    </footer>
  );
}
