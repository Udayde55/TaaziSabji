"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, LayoutGrid, ShoppingBasket, Package, User } from "lucide-react";
import { useCart } from "@/store/cart";
import { useT } from "@/lib/i18n";
import { useEffect, useState } from "react";

export default function BottomNav() {
  const path = usePathname();
  const { t } = useT();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const count = useCart((s) => s.items.reduce((n, i) => n + i.qty, 0));

  const tabs = [
    { href: "/", label: t("home"), icon: Home },
    { href: "/products", label: t("categories"), icon: LayoutGrid },
    { href: "/cart", label: t("cart"), icon: ShoppingBasket },
    { href: "/orders", label: t("orders"), icon: Package },
    { href: "/profile", label: t("profile"), icon: User },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 border-t border-green-100 bg-white/95 backdrop-blur md:hidden">
      <ul className="grid grid-cols-5">
        {tabs.map(({ href, label, icon: Icon }) => {
          const active = href === "/" ? path === "/" : path.startsWith(href);
          return (
            <li key={href}>
              <Link
                href={href}
                className={`relative flex flex-col items-center gap-0.5 py-2 text-[11px] font-medium ${
                  active ? "text-green-700" : "text-gray-500"
                }`}
              >
                <span className={`rounded-xl px-3 py-1 ${active ? "bg-green-50" : ""}`}>
                  <Icon size={21} strokeWidth={active ? 2.5 : 2} />
                </span>
                {label}
                {href === "/cart" && mounted && count > 0 && (
                  <span className="absolute right-4 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-white">
                    {count}
                  </span>
                )}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
