"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Leaf, Search, MapPin, ShoppingBasket, User, Languages, Tractor, LayoutDashboard } from "lucide-react";
import { useCart } from "@/store/cart";
import { useApp } from "@/store/app";
import { useT } from "@/lib/i18n";

export default function Header() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const items = useCart((s) => s.items);
  const count = items.reduce((n, i) => n + i.qty, 0);
  const { lang, setLang, location, setLocation, user } = useApp();
  const { t } = useT();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(`/products?q=${encodeURIComponent(q.trim())}`);
  };

  const pickLocation = () => {
    const v = window.prompt(lang === "hi" ? "अपना शहर / क्षेत्र लिखें" : "Enter your city / area", location);
    if (v && v.trim()) setLocation(v.trim());
  };

  return (
    <header className="sticky top-0 z-50 bg-green-700 text-white shadow-md">
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex h-16 items-center gap-3 md:gap-5">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-green-700">
              <Leaf size={20} strokeWidth={2.5} />
            </span>
            <span className="text-lg font-bold leading-none">
              Taazi<span className="text-lime-300">Sabzi</span>
            </span>
          </Link>

          <form onSubmit={submit} className="hidden md:flex flex-1 max-w-xl items-center rounded-xl bg-white px-3 text-gray-700">
            <Search size={18} className="text-gray-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("searchPlaceholder")}
              className="h-10 flex-1 bg-transparent px-2 text-sm outline-none"
            />
          </form>

          <button onClick={pickLocation} className="hidden md:flex items-center gap-1 rounded-lg px-2 py-1 text-sm hover:bg-green-800">
            <MapPin size={16} className="text-lime-300" />
            <span className="max-w-[140px] truncate">{mounted ? location : "Khutpipariya, MP"}</span>
          </button>

          <div className="ml-auto flex items-center gap-1 md:gap-2">
            <button
              onClick={() => setLang(lang === "en" ? "hi" : "en")}
              className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs font-semibold hover:bg-green-800"
              title="Switch language"
            >
              <Languages size={16} /> {mounted ? (lang === "en" ? "हिं" : "EN") : "हिं"}
            </button>
            <Link href="/sell" className="hidden md:flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm hover:bg-green-800">
              <Tractor size={18} /> {t("sellSabzi")}
            </Link>
            {mounted && user && (user.role === "seller" || user.role === "admin") && (
              <Link href={user.role === "admin" ? "/admin" : "/seller"} className="hidden md:flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm hover:bg-green-800">
                <LayoutDashboard size={18} /> Dashboard
              </Link>
            )}
            <Link href="/cart" className="relative rounded-lg p-2 hover:bg-green-800">
              <ShoppingBasket size={22} />
              {mounted && count > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-accent px-1 text-[11px] font-bold">
                  {count}
                </span>
              )}
            </Link>
            <Link href={mounted && user ? "/profile" : "/login"} className="hidden md:block rounded-lg p-2 hover:bg-green-800">
              <User size={22} />
            </Link>
          </div>
        </div>

        {/* mobile search + location */}
        <div className="flex items-center gap-2 pb-3 md:hidden">
          <form onSubmit={submit} className="flex flex-1 items-center rounded-xl bg-white px-3 text-gray-700">
            <Search size={18} className="text-gray-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("searchPlaceholder")}
              className="h-10 flex-1 bg-transparent px-2 text-sm outline-none"
            />
          </form>
          <button onClick={pickLocation} className="flex items-center gap-1 rounded-xl bg-green-800 px-2.5 py-2.5 text-xs">
            <MapPin size={14} className="text-lime-300" />
            <span className="max-w-[80px] truncate">{mounted ? location.split(",")[0] : "Khutpipariya"}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
