"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Zap, Truck, Leaf, ShieldCheck, Star, MapPin, Tractor, Timer, BadgePercent, MessageCircle } from "lucide-react";
import type { Category } from "@/db/schema";
import type { ProductDTO } from "@/lib/data";
import ProductCard from "@/components/product/ProductCard";
import { SectionHeader } from "@/components/ui/Common";
import { useT } from "@/lib/i18n";
import { CONTACT } from "@/components/layout/Footer";

export function Hero() {
  const { t, lang } = useT();
  return (
    <section className="mx-auto max-w-7xl px-4 pt-4 md:pt-6">
      <div className="relative overflow-hidden rounded-3xl bg-green-800 text-white shadow-lg">
        <Image src="/images/hero.jpg" alt="Fresh vegetables" fill priority sizes="100vw" className="object-cover opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/90 via-green-800/70 to-transparent" />
        <div className="relative px-6 py-12 md:px-12 md:py-20 max-w-xl">
          <motion.span
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-1 rounded-full bg-white/15 px-3 py-1 text-xs font-medium backdrop-blur"
          >
            <Timer size={14} className="text-lime-300" /> {t("deliveryIn10")} · Khutpipariya
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-4 text-3xl font-bold leading-tight md:text-5xl"
          >
            {t("heroTitle")}
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-3 text-sm text-green-50 md:text-base">
            {t("heroSub")}
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-6 flex flex-wrap gap-3">
            <Link href="/products" className="btn-accent">
              <Truck size={18} /> {t("sameDay")}
            </Link>
            <Link href="/products" className="inline-flex items-center gap-2 rounded-xl bg-white px-5 py-2.5 font-semibold text-green-800 hover:bg-green-50">
              {t("shopNow")}
            </Link>
            <Link href="/sell" className="inline-flex items-center gap-2 rounded-xl border border-white/60 px-5 py-2.5 font-semibold text-white hover:bg-white/10">
              <Tractor size={18} /> {lang === "hi" ? "किसान: सब्ज़ी बेचें" : "Farmer? Sell Sabzi"}
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export function Categories({ cats }: { cats: Category[] }) {
  const { t, lang } = useT();
  return (
    <section className="mx-auto max-w-7xl px-4 pt-8">
      <SectionHeader title={t("categories")} href="/products" linkLabel={t("viewAll")} />
      <div className="no-scrollbar flex gap-3 overflow-x-auto pb-2 md:grid md:grid-cols-6">
        {cats.map((c, i) => (
          <motion.div key={c.slug} initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
            <Link
              href={`/products?category=${c.slug}`}
              className="card flex min-w-[110px] flex-col items-center gap-2 px-3 py-4 text-center transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <span className="grid h-14 w-14 place-items-center rounded-full bg-green-50 text-3xl">{c.emoji}</span>
              <span className="text-xs font-semibold text-gray-800 md:text-sm">{lang === "hi" ? c.nameHi : c.name}</span>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export function ProductSection({ title, sub, products, href }: { title: string; sub?: string; products: ProductDTO[]; href: string }) {
  const { t } = useT();
  if (!products.length) return null;
  return (
    <section className="mx-auto max-w-7xl px-4 pt-10">
      <SectionHeader title={title} sub={sub} href={href} linkLabel={t("viewAll")} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">
        {products.map((p) => (
          <ProductCard key={p.id} p={p} />
        ))}
      </div>
    </section>
  );
}

const sellers = [
  { name: "TaaziSabzi Farm", area: "Khutpipariya", rating: 4.8, dist: "0 km", tag: "Verified Farm", emoji: "🚜" },
  { name: "Ramesh Patel (Kisaan)", area: "Khutpipariya", rating: 4.7, dist: "1.2 km", tag: "Organic", emoji: "👨‍🌾" },
  { name: "Gokul Sabzi Mandi", area: "Gadarwara", rating: 4.5, dist: "8 km", tag: "Wholesale", emoji: "🏪" },
  { name: "Savita Devi SHG", area: "Chichli", rating: 4.9, dist: "6 km", tag: "Women Farmers", emoji: "🌾" },
];

export function NearbySellers() {
  const { t } = useT();
  return (
    <section className="mx-auto max-w-7xl px-4 pt-10">
      <SectionHeader title={t("nearbySellers")} href="/#map" linkLabel="Map" />
      <div className="no-scrollbar flex gap-3 overflow-x-auto pb-2 md:grid md:grid-cols-4">
        {sellers.map((s) => (
          <div key={s.name} className="card flex min-w-[220px] items-center gap-3 p-4">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-green-50 text-2xl">{s.emoji}</span>
            <div className="min-w-0">
              <div className="truncate font-semibold text-gray-900">{s.name}</div>
              <div className="flex items-center gap-1 text-xs text-gray-500">
                <Star size={12} className="fill-amber-400 text-amber-400" /> {s.rating} · <MapPin size={11} /> {s.dist}
              </div>
              <span className="mt-1 inline-block rounded-md bg-green-50 px-2 py-0.5 text-[10px] font-semibold text-green-700">{s.tag}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function Offers() {
  const { t, lang } = useT();
  const offers = [
    { code: "FRESH10", text: lang === "hi" ? "₹199+ ऑर्डर पर 10% छूट" : "10% off on orders above ₹199", color: "from-orange-400 to-amber-500" },
    { code: "SABZI50", text: lang === "hi" ? "₹499+ पर ₹50 की छूट" : "Flat ₹50 off above ₹499", color: "from-green-600 to-green-700" },
    { code: "WELCOME", text: lang === "hi" ? "पहले ऑर्डर पर ₹30 छूट" : "₹30 off on first order", color: "from-rose-400 to-red-500" },
  ];
  return (
    <section className="mx-auto max-w-7xl px-4 pt-10">
      <SectionHeader title={t("offersTitle")} />
      <div className="no-scrollbar flex gap-3 overflow-x-auto pb-2 md:grid md:grid-cols-3">
        {offers.map((o) => (
          <div key={o.code} className={`flex min-w-[260px] items-center justify-between rounded-2xl bg-gradient-to-r ${o.color} p-4 text-white shadow`}>
            <div>
              <div className="flex items-center gap-1 text-xs opacity-90"><BadgePercent size={14} /> Coupon</div>
              <div className="text-lg font-bold">{o.code}</div>
              <div className="text-xs opacity-90">{o.text}</div>
            </div>
            <Link href="/products" className="rounded-lg bg-white/20 px-3 py-1.5 text-xs font-semibold backdrop-blur hover:bg-white/30">
              {t("shopNow")}
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
}

export function WhyUs() {
  const { t, lang } = useT();
  const points = [
    { icon: Leaf, title: lang === "hi" ? "100% ताज़ा" : "100% Farm Fresh", sub: lang === "hi" ? "रोज़ सुबह खेत से तोड़ी हुई" : "Harvested every morning from local farms" },
    { icon: Zap, title: lang === "hi" ? "10 मिनट डिलीवरी" : "10-Min Express", sub: lang === "hi" ? "खुटपिपरिया में सुपरफास्ट" : "Superfast in Khutpipariya area" },
    { icon: Truck, title: lang === "hi" ? "सेम डे डिलीवरी" : "Same Day Delivery", sub: lang === "hi" ? "₹299+ पर फ्री डिलीवरी" : "Free delivery above ₹299" },
    { icon: ShieldCheck, title: lang === "hi" ? "ताज़गी की गारंटी" : "Freshness Guarantee", sub: lang === "hi" ? "पसंद न आए तो बदलें" : "Easy replacement if not fresh" },
  ];
  return (
    <section className="mx-auto max-w-7xl px-4 pt-10">
      <SectionHeader title={t("whyUs")} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">
        {points.map(({ icon: Icon, title, sub }) => (
          <div key={title} className="card p-4 text-center">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-green-50 text-green-700">
              <Icon size={24} />
            </span>
            <div className="mt-3 font-semibold text-gray-900">{title}</div>
            <div className="mt-1 text-xs text-gray-500">{sub}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function MapSection() {
  const { lang } = useT();
  return (
    <section id="map" className="mx-auto max-w-7xl px-4 pt-10">
      <SectionHeader
        title={lang === "hi" ? "हमारी लोकेशन – खुटपिपरिया, मध्य प्रदेश" : "Our Location – Khutpipariya, Madhya Pradesh"}
        sub={lang === "hi" ? "यहाँ हमारी सेवा उपलब्ध है" : "We are available here · Delivery radius ~15 km"}
      />
      <div className="card overflow-hidden md:grid md:grid-cols-3">
        <iframe
          title="Khutpipariya map"
          src="https://www.google.com/maps?q=Khutpipariya,+Madhya+Pradesh&z=12&output=embed"
          className="h-72 w-full border-0 md:col-span-2 md:h-96"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
        />
        <div className="flex flex-col justify-center gap-3 p-5">
          <div className="flex items-start gap-2 text-sm text-gray-700"><MapPin className="mt-0.5 shrink-0 text-green-700" size={18} /> {CONTACT.place}</div>
          <a href={`tel:${CONTACT.phone.replace(/\s/g, "")}`} className="text-sm font-semibold text-green-700">📞 {CONTACT.phone}</a>
          <a href={`mailto:${CONTACT.email}`} className="text-sm font-semibold text-green-700">✉️ {CONTACT.email}</a>
          <a href={`https://wa.me/${CONTACT.phoneRaw}?text=${encodeURIComponent("Namaste! Mujhe sabzi order karni hai.")}`} target="_blank" rel="noreferrer" className="btn-primary mt-2 bg-[#25D366] hover:bg-[#1ebe5a]">
            <MessageCircle size={18} /> WhatsApp Order
          </a>
          <a href="https://www.google.com/maps/search/?api=1&query=Khutpipariya,+Madhya+Pradesh" target="_blank" rel="noreferrer" className="btn-outline">
            Open in Google Maps
          </a>
        </div>
      </div>
    </section>
  );
}
