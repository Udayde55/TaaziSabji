"use client";

import type { ProductDTO } from "@/lib/data";
import { ProductSection } from "@/components/home/HomeSections";
import { useT } from "@/lib/i18n";

export default function HomeTitles({ featured, seasonal, bestSellers }: { featured: ProductDTO[]; seasonal: ProductDTO[]; bestSellers: ProductDTO[] }) {
  const { t, lang } = useT();
  return (
    <>
      <ProductSection title={t("featured")} sub={lang === "hi" ? "आज सुबह खेत से तोड़ी हुई" : "Harvested this morning"} products={featured} href="/products" />
      <ProductSection title={t("seasonalPicks")} products={seasonal} href="/products?category=seasonal" />
      <ProductSection title={t("bestSellers")} products={bestSellers} href="/products?sort=popular" />
    </>
  );
}
