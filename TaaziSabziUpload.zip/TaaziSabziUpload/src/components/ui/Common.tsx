"use client";

import Link from "next/link";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";

export function SectionHeader({ title, sub, href, linkLabel }: { title: string; sub?: string; href?: string; linkLabel?: string }) {
  return (
    <div className="mb-4 flex items-end justify-between">
      <div>
        <h2 className="text-xl font-bold text-gray-900 md:text-2xl">{title}</h2>
        {sub && <p className="text-sm text-gray-500">{sub}</p>}
      </div>
      {href && (
        <Link href={href} className="flex items-center gap-0.5 text-sm font-semibold text-green-700">
          {linkLabel} <ChevronRight size={16} />
        </Link>
      )}
    </div>
  );
}

export function EmptyState({ emoji, title, sub, action }: { emoji: string; title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="card mx-auto my-10 flex max-w-md flex-col items-center px-6 py-12 text-center">
      <div className="text-6xl">{emoji}</div>
      <h3 className="mt-4 text-lg font-bold text-gray-900">{title}</h3>
      {sub && <p className="mt-1 text-sm text-gray-500">{sub}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Spinner() {
  return (
    <div className="flex justify-center py-16">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-green-100 border-t-green-700" />
    </div>
  );
}

export function PageTitle({ title, sub }: { title: string; sub?: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-bold text-gray-900 md:text-3xl">{title}</h1>
      {sub && <p className="mt-1 text-sm text-gray-500">{sub}</p>}
    </div>
  );
}
