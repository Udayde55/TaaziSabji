"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Minus, Plus, Star, MapPin, Leaf, Truck, Timer, ShieldCheck, ChevronLeft, Heart } from "lucide-react";
import type { ProductDTO } from "@/lib/data";
import { useCart } from "@/store/cart";
import { useApp } from "@/store/app";
import { useT, unitLabel } from "@/lib/i18n";
import { toast } from "@/components/ui/Toaster";
import ProductCard from "@/components/product/ProductCard";

type Review = { id: number; name: string; rating: number; comment: string | null; date: string };

export default function ProductDetail({ p, reviews: initial, related }: { p: ProductDTO; reviews: Review[]; related: ProductDTO[] }) {
  const { t, lang } = useT();
  const router = useRouter();
  const add = useCart((s) => s.add);
  const { wishlist, toggleWishlist } = useApp();
  const [qty, setQty] = useState(1);
  const [reviews, setReviews] = useState(initial);
  const [rv, setRv] = useState({ name: "", rating: 5, comment: "" });
  const name = lang === "hi" ? p.nameHi : p.name;
  const wholesale = p.wholesalePrice && p.wholesaleMinQty && qty >= p.wholesaleMinQty;
  const unitPrice = wholesale ? p.wholesalePrice! : p.price;

  const addToCart = () => {
    add({ id: p.id, slug: p.slug, name: p.name, nameHi: p.nameHi, image: p.image, price: p.price, unit: p.unit, stock: p.stock }, qty);
    toast(`${qty} ${unitLabel(p.unit, lang)} ${name} ${t("added")} 🧺`);
  };

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/reviews", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...rv, productId: p.id }) });
    if (res.ok) {
      const r = await res.json();
      setReviews([{ id: r.id, name: r.name, rating: r.rating, comment: r.comment, date: new Date().toISOString().slice(0, 10) }, ...reviews]);
      setRv({ name: "", rating: 5, comment: "" });
      toast(lang === "hi" ? "धन्यवाद! रिव्यू जोड़ा गया" : "Thanks! Review added");
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <button onClick={() => router.back()} className="mb-4 flex items-center gap-1 text-sm font-medium text-green-700">
        <ChevronLeft size={18} /> {lang === "hi" ? "वापस" : "Back"}
      </button>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="card relative aspect-square overflow-hidden">
          <Image src={p.image} alt={p.name} fill priority sizes="(max-width:768px) 100vw, 50vw" className="object-cover" />
          <div className="absolute left-3 top-3 flex gap-2">
            <span className="rounded-md bg-green-700 px-2 py-1 text-xs font-semibold text-white">{t("farmFresh")}</span>
            {p.organic && <span className="rounded-md bg-lime-500 px-2 py-1 text-xs font-semibold text-white">{t("organic")}</span>}
          </div>
          <button onClick={() => toggleWishlist(p.id)} className="absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-full bg-white shadow">
            <Heart size={20} className={wishlist.includes(p.id) ? "fill-sale text-sale" : "text-gray-500"} />
          </button>
        </div>

        <div>
          <h1 className="text-2xl font-bold text-gray-900 md:text-3xl">{name}</h1>
          <p className="text-sm text-gray-500">{lang === "hi" ? p.name : p.nameHi}{p.variety ? ` · ${p.variety}` : ""}</p>
          <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-gray-600">
            <span className="flex items-center gap-1 rounded-md bg-green-50 px-2 py-0.5 font-semibold text-green-800"><Star size={14} className="fill-amber-400 text-amber-400" /> {p.rating.toFixed(1)}</span>
            <span>{p.sold}+ sold</span>
            <span className="flex items-center gap-1"><MapPin size={14} /> {p.sellerName}, {p.sellerArea}</span>
          </div>

          <div className="mt-5 flex items-end gap-2">
            <span className="text-3xl font-bold text-green-800">₹{unitPrice}</span>
            <span className="pb-1 text-gray-500">/ {unitLabel(p.unit, lang)}</span>
            {wholesale && <span className="mb-1 rounded-md bg-accent px-2 py-0.5 text-xs font-semibold text-white">{t("wholesale")} rate</span>}
          </div>
          {p.wholesalePrice && (
            <p className="mt-1 text-sm text-accent-dark">
              {lang === "hi" ? `थोक भाव: ₹${p.wholesalePrice}/${unitLabel(p.unit, lang)} (${p.wholesaleMinQty}+ पर)` : `Wholesale: ₹${p.wholesalePrice}/${unitLabel(p.unit, lang)} on ${p.wholesaleMinQty}+ ${unitLabel(p.unit, lang)}`}
            </p>
          )}
          <p className="mt-1 text-xs text-gray-500">
            {p.stock > 0 ? (lang === "hi" ? `स्टॉक में: ${p.stock} ${unitLabel(p.unit, lang)}` : `In stock: ${p.stock} ${unitLabel(p.unit, lang)}`) : t("outOfStock")}
            {p.freshnessDate && ` · ${lang === "hi" ? "तोड़ी गई" : "Harvested"}: ${p.freshnessDate}`}
          </p>

          <p className="mt-4 text-gray-700">{p.description}</p>

          <div className="mt-6 flex items-center gap-4">
            <div className="flex items-center rounded-xl border-2 border-green-700">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="px-3 py-2 text-green-700"><Minus size={18} /></button>
              <input type="number" value={qty} min={1} max={p.stock} onChange={(e) => setQty(Math.max(1, Math.min(p.stock, Number(e.target.value) || 1)))} className="w-14 text-center font-bold outline-none" />
              <button onClick={() => setQty(Math.min(p.stock, qty + 1))} className="px-3 py-2 text-green-700"><Plus size={18} /></button>
            </div>
            <span className="text-sm text-gray-500">= ₹{(unitPrice * qty).toFixed(0)}</span>
          </div>

          <div className="mt-5 flex gap-3">
            <button onClick={addToCart} disabled={p.stock <= 0} className="btn-primary flex-1 py-3">
              <Plus size={18} /> {t("addToCart")} · ₹{(unitPrice * qty).toFixed(0)}
            </button>
            <Link href="/checkout" onClick={addToCart} className="btn-accent flex-1 py-3">
              <Timer size={18} /> {lang === "hi" ? "अभी खरीदें" : "Buy Now"}
            </Link>
          </div>

          <div className="mt-6 grid grid-cols-3 gap-2 text-center text-xs text-gray-600">
            <div className="card p-3"><Timer className="mx-auto text-green-700" size={20} /><div className="mt-1 font-medium">{t("deliveryIn10")}</div></div>
            <div className="card p-3"><Truck className="mx-auto text-green-700" size={20} /><div className="mt-1 font-medium">{t("sameDay")}</div></div>
            <div className="card p-3"><ShieldCheck className="mx-auto text-green-700" size={20} /><div className="mt-1 font-medium">{lang === "hi" ? "ताज़गी गारंटी" : "Fresh Guarantee"}</div></div>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-12 grid gap-6 md:grid-cols-2">
        <div>
          <h2 className="text-xl font-bold text-gray-900">{lang === "hi" ? "रेटिंग और रिव्यू" : "Ratings & Reviews"}</h2>
          {reviews.length === 0 ? (
            <p className="mt-3 text-sm text-gray-500">{lang === "hi" ? "अभी कोई रिव्यू नहीं। पहला रिव्यू दें!" : "No reviews yet. Be the first!"}</p>
          ) : (
            <ul className="mt-3 space-y-3">
              {reviews.map((r) => (
                <li key={r.id} className="card p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{r.name}</span>
                    <span className="flex items-center gap-0.5 text-amber-500">{Array.from({ length: r.rating }).map((_, i) => <Star key={i} size={14} className="fill-amber-400" />)}</span>
                  </div>
                  {r.comment && <p className="mt-1 text-sm text-gray-600">{r.comment}</p>}
                  <p className="mt-1 text-xs text-gray-400">{r.date}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
        <form onSubmit={submitReview} className="card space-y-3 p-5">
          <h3 className="font-semibold">{lang === "hi" ? "अपना रिव्यू लिखें" : "Write a review"}</h3>
          <input required value={rv.name} onChange={(e) => setRv({ ...rv, name: e.target.value })} placeholder={lang === "hi" ? "आपका नाम" : "Your name"} className="input" />
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((n) => (
              <button type="button" key={n} onClick={() => setRv({ ...rv, rating: n })}>
                <Star size={24} className={n <= rv.rating ? "fill-amber-400 text-amber-400" : "text-gray-300"} />
              </button>
            ))}
          </div>
          <textarea value={rv.comment} onChange={(e) => setRv({ ...rv, comment: e.target.value })} placeholder={lang === "hi" ? "सब्ज़ी कैसी लगी?" : "How was the sabzi?"} className="input" rows={3} />
          <button className="btn-primary w-full">{lang === "hi" ? "रिव्यू भेजें" : "Submit Review"}</button>
        </form>
      </section>

      {related.length > 0 && (
        <section className="mt-12">
          <h2 className="mb-4 flex items-center gap-2 text-xl font-bold text-gray-900"><Leaf className="text-green-700" size={20} /> {lang === "hi" ? "इसी तरह की सब्ज़ियाँ" : "You may also like"}</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">
            {related.map((r) => <ProductCard key={r.id} p={r} />)}
          </div>
        </section>
      )}
    </div>
  );
}
