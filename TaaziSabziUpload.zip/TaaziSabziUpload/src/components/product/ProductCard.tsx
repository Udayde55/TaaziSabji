"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Heart, Plus, Minus, Star, MapPin } from "lucide-react";
import type { ProductDTO } from "@/lib/data";
import { useCart } from "@/store/cart";
import { useApp } from "@/store/app";
import { useT, unitLabel } from "@/lib/i18n";
import { toast } from "@/components/ui/Toaster";

export default function ProductCard({ p }: { p: ProductDTO }) {
  const { t, lang } = useT();
  const { items, add, setQty } = useCart();
  const { wishlist, toggleWishlist } = useApp();
  const inCart = items.find((i) => i.id === p.id);
  const liked = wishlist.includes(p.id);
  const name = lang === "hi" ? p.nameHi : p.name;

  const handleAdd = () => {
    add({ id: p.id, slug: p.slug, name: p.name, nameHi: p.nameHi, image: p.image, price: p.price, unit: p.unit, stock: p.stock });
    toast(`${name} ${t("added")} 🧺`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.3 }}
      className="card group flex flex-col overflow-hidden transition hover:shadow-md"
    >
      <Link href={`/products/${p.slug}`} className="relative block aspect-square overflow-hidden bg-green-50">
        <Image
          src={p.image}
          alt={p.name}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className="object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute left-2 top-2 flex flex-col gap-1">
          <span className="rounded-md bg-green-700 px-2 py-0.5 text-[10px] font-semibold text-white">{t("farmFresh")}</span>
          {p.organic && <span className="rounded-md bg-lime-500 px-2 py-0.5 text-[10px] font-semibold text-white">{t("organic")}</span>}
          {p.stock > 0 && p.stock <= 10 && <span className="rounded-md bg-sale px-2 py-0.5 text-[10px] font-semibold text-white">{t("lowStock")}</span>}
        </div>
        <button
          onClick={(e) => {
            e.preventDefault();
            toggleWishlist(p.id);
          }}
          className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-white/90 shadow"
          aria-label="wishlist"
        >
          <Heart size={16} className={liked ? "fill-sale text-sale" : "text-gray-500"} />
        </button>
      </Link>

      <div className="flex flex-1 flex-col p-3">
        <Link href={`/products/${p.slug}`} className="line-clamp-1 font-semibold text-gray-900">
          {name}
        </Link>
        <div className="mt-0.5 flex items-center gap-1 text-[11px] text-gray-500">
          <Star size={12} className="fill-amber-400 text-amber-400" /> {p.rating.toFixed(1)}
          <span className="mx-1">·</span>
          <MapPin size={11} /> <span className="truncate">{p.sellerArea.split(",")[0]}</span>
        </div>
        <div className="mt-2 flex items-end justify-between gap-2">
          <div>
            <div className="text-lg font-bold text-green-800">
              ₹{p.price}
              <span className="text-xs font-medium text-gray-500">/{unitLabel(p.unit, lang)}</span>
            </div>
            {p.wholesalePrice && (
              <div className="text-[10px] text-accent-dark font-medium">
                {t("wholesale")}: ₹{p.wholesalePrice} ({p.wholesaleMinQty}+)
              </div>
            )}
          </div>
          {p.stock <= 0 ? (
            <span className="rounded-lg bg-gray-100 px-2 py-1 text-xs text-gray-500">{t("outOfStock")}</span>
          ) : inCart ? (
            <div className="flex items-center rounded-lg bg-green-700 text-white">
              <button onClick={() => setQty(p.id, inCart.qty - 1)} className="px-2 py-1.5" aria-label="minus">
                <Minus size={14} />
              </button>
              <span className="min-w-5 text-center text-sm font-semibold">{inCart.qty}</span>
              <button onClick={() => setQty(p.id, inCart.qty + 1)} className="px-2 py-1.5" aria-label="plus">
                <Plus size={14} />
              </button>
            </div>
          ) : (
            <button onClick={handleAdd} className="flex items-center gap-1 rounded-lg bg-green-700 px-3 py-1.5 text-sm font-semibold text-white hover:bg-green-800 active:scale-95">
              <Plus size={14} /> {t("addToCart")}
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}
