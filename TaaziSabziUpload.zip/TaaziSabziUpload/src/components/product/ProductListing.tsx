"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { SlidersHorizontal, Search } from "lucide-react";
import type { Category } from "@/db/schema";
import type { ProductDTO } from "@/lib/data";
import ProductCard from "@/components/product/ProductCard";
import { EmptyState, Spinner, PageTitle } from "@/components/ui/Common";
import { useT } from "@/lib/i18n";

export default function ProductListing({ cats }: { cats: Category[] }) {
  const sp = useSearchParams();
  const router = useRouter();
  const { lang } = useT();
  const [list, setList] = useState<ProductDTO[] | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const category = sp.get("category") ?? "all";
  const q = sp.get("q") ?? "";
  const sort = sp.get("sort") ?? "popular";
  const organic = sp.get("organic") === "1";
  const maxPrice = sp.get("maxPrice") ?? "";

  const setParam = (k: string, v: string) => {
    const n = new URLSearchParams(sp.toString());
    if (v && v !== "all" && v !== "0") n.set(k, v);
    else n.delete(k);
    router.push(`/products?${n.toString()}`);
  };

  useEffect(() => {
    setList(null);
    fetch(`/api/products?${sp.toString()}`)
      .then((r) => r.json())
      .then(setList)
      .catch(() => setList([]));
  }, [sp]);

  const allCats = [{ slug: "all", name: "All", nameHi: "सभी", emoji: "🧺", id: 0 }, ...cats];

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <PageTitle
        title={q ? `${lang === "hi" ? "खोज परिणाम" : "Results for"} "${q}"` : lang === "hi" ? "सभी सब्ज़ियाँ" : "All Vegetables"}
        sub={lang === "hi" ? "खुटपिपरिया के किसानों से ताज़ी" : "Fresh from Khutpipariya farmers · Updated daily"}
      />

      <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-3">
        {allCats.map((c) => (
          <button
            key={c.slug}
            onClick={() => setParam("category", c.slug)}
            className={`flex shrink-0 items-center gap-1.5 rounded-full border px-4 py-2 text-sm font-medium transition ${
              category === c.slug ? "border-green-700 bg-green-700 text-white" : "border-green-100 bg-white text-gray-700 hover:border-green-500"
            }`}
          >
            <span>{c.emoji}</span> {lang === "hi" ? c.nameHi : c.name}
          </button>
        ))}
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-2">
        <button onClick={() => setShowFilters((s) => !s)} className="btn-outline py-2 text-sm">
          <SlidersHorizontal size={16} /> {lang === "hi" ? "फ़िल्टर" : "Filters"}
        </button>
        <select value={sort} onChange={(e) => setParam("sort", e.target.value)} className="input w-auto">
          <option value="popular">{lang === "hi" ? "लोकप्रिय" : "Popular"}</option>
          <option value="price_asc">{lang === "hi" ? "कीमत: कम से ज़्यादा" : "Price: Low to High"}</option>
          <option value="price_desc">{lang === "hi" ? "कीमत: ज़्यादा से कम" : "Price: High to Low"}</option>
          <option value="rating">{lang === "hi" ? "रेटिंग" : "Top Rated"}</option>
        </select>
        <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm">
          <input type="checkbox" checked={organic} onChange={(e) => setParam("organic", e.target.checked ? "1" : "")} className="accent-green-700" />
          🌱 {lang === "hi" ? "सिर्फ़ ऑर्गेनिक" : "Organic only"}
        </label>
        {list && <span className="ml-auto text-sm text-gray-500">{list.length} items</span>}
      </div>

      {showFilters && (
        <div className="card mt-3 grid gap-4 p-4 md:grid-cols-3">
          <div>
            <label className="label">{lang === "hi" ? "अधिकतम कीमत" : "Max price"}: ₹{maxPrice || "100"}</label>
            <input type="range" min={10} max={100} step={5} value={maxPrice || 100} onChange={(e) => setParam("maxPrice", e.target.value === "100" ? "" : e.target.value)} className="w-full accent-green-700" />
          </div>
          <div>
            <label className="label">{lang === "hi" ? "डिलीवरी दूरी" : "Delivery radius"}</label>
            <select className="input">
              <option>Within 5 km (Khutpipariya)</option>
              <option>Within 15 km</option>
              <option>Within 30 km</option>
            </select>
          </div>
          <div>
            <label className="label">{lang === "hi" ? "खोजें" : "Search"}</label>
            <div className="flex items-center rounded-xl border border-gray-200 bg-white px-3">
              <Search size={16} className="text-gray-400" />
              <input defaultValue={q} onKeyDown={(e) => e.key === "Enter" && setParam("q", (e.target as HTMLInputElement).value)} placeholder="Tamatar, Aalu..." className="h-10 flex-1 bg-transparent px-2 text-sm outline-none" />
            </div>
          </div>
        </div>
      )}

      {list === null ? (
        <Spinner />
      ) : list.length === 0 ? (
        <EmptyState emoji="🥕" title={lang === "hi" ? "कोई सब्ज़ी नहीं मिली" : "No vegetables found"} sub={lang === "hi" ? "फ़िल्टर बदलकर देखें" : "Try changing filters or search"} action={<button onClick={() => router.push("/products")} className="btn-primary">{lang === "hi" ? "सभी देखें" : "Show all"}</button>} />
      ) : (
        <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">
          {list.map((p) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>
      )}
    </div>
  );
}
