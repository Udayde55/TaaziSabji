"use client";

import Link from "next/link";
import { useEffect, useState, useCallback } from "react";
import { IndianRupee, Package, AlertTriangle, TrendingUp, Plus, Trash2, Tractor, Users, Percent, RefreshCw } from "lucide-react";
import type { ProductDTO } from "@/lib/data";
import { useApp } from "@/store/app";
import { useT } from "@/lib/i18n";
import { EmptyState, Spinner, PageTitle } from "@/components/ui/Common";
import { toast } from "@/components/ui/Toaster";
import { STATUS_FLOW, STATUS_LABEL } from "@/lib/status";

type Order = { id: number; orderNumber: string; status: string; total: string; createdAt: string; customerName: string; phone: string; area: string; paymentMethod: string; items: { name: string; qty: number }[] };
type SellReq = { id: number; farmerName: string; phone: string; village: string; vegetable: string; quantity: string; unit: string; expectedPrice: string; organic: boolean; status: string; createdAt: string };

const COMMISSION = 0.08;

export default function Dashboard({ mode }: { mode: "seller" | "admin" }) {
  const { user } = useApp();
  const { lang } = useT();
  const [mounted, setMounted] = useState(false);
  const [tab, setTab] = useState<"overview" | "inventory" | "orders" | "farmers">("overview");
  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [reqs, setReqs] = useState<SellReq[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [np, setNp] = useState({ name: "", nameHi: "", price: "", wholesalePrice: "", wholesaleMinQty: "", unit: "kg", stock: "", categorySlug: "seasonal", organic: false, seasonal: false, image: "/images/tomato.jpg" });

  const load = useCallback(async () => {
    setLoading(true);
    const [p, o, r] = await Promise.all([fetch("/api/products").then((r) => r.json()), fetch("/api/orders").then((r) => r.json()), fetch("/api/sell-requests").then((r) => r.json())]);
    setProducts(p);
    setOrders(o);
    setReqs(r);
    setLoading(false);
  }, []);

  useEffect(() => {
    setMounted(true);
    load();
  }, [load]);

  if (!mounted) return <Spinner />;
  if (!user || (mode === "admin" ? user.role !== "admin" : !["seller", "admin"].includes(user.role)))
    return <EmptyState emoji="🔐" title={lang === "hi" ? "लॉगिन ज़रूरी है" : "Login required"} sub={mode === "admin" ? "Admin access only" : lang === "hi" ? "सेलर या एडमिन अकाउंट से लॉगिन करें" : "Login with a seller or admin account"} action={<Link href="/login" className="btn-primary">Login</Link>} />;

  const delivered = orders.filter((o) => o.status === "delivered");
  const revenue = delivered.reduce((n, o) => n + Number(o.total), 0);
  const pendingRevenue = orders.filter((o) => !["delivered", "cancelled"].includes(o.status)).reduce((n, o) => n + Number(o.total), 0);
  const lowStock = products.filter((p) => p.stock <= 10);
  const today = new Date().toDateString();
  const todayOrders = orders.filter((o) => new Date(o.createdAt).toDateString() === today);
  const popular = [...products].sort((a, b) => b.sold - a.sold).slice(0, 5);
  const hours = orders.reduce<Record<number, number>>((acc, o) => { const h = new Date(o.createdAt).getHours(); acc[h] = (acc[h] ?? 0) + 1; return acc; }, {});
  const peakHour = Object.entries(hours).sort((a, b) => b[1] - a[1])[0]?.[0];

  const updateStock = async (id: number, stock: number) => {
    await fetch("/api/products", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, stock: Math.max(0, stock) }) });
    setProducts((ps) => ps.map((p) => (p.id === id ? { ...p, stock: Math.max(0, stock) } : p)));
  };
  const updatePrice = async (id: number, price: number) => {
    await fetch("/api/products", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, price }) });
    setProducts((ps) => ps.map((p) => (p.id === id ? { ...p, price } : p)));
    toast("Price updated");
  };
  const removeProduct = async (id: number) => {
    if (!confirm("Remove this product?")) return;
    await fetch(`/api/products?id=${id}`, { method: "DELETE" });
    setProducts((ps) => ps.filter((p) => p.id !== id));
  };
  const addProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/products", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...np, sellerName: user.name, sellerArea: user.area || "Khutpipariya, MP" }) });
    if (res.ok) {
      setProducts([await res.json(), ...products]);
      setShowAdd(false);
      toast("Product added 🥬");
    }
  };
  const setOrderStatus = async (id: number, status: string) => {
    const r = await fetch("/api/orders", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    const o = await r.json();
    setOrders((os) => os.map((x) => (x.id === id ? o : x)));
    toast(`Order ${STATUS_LABEL[status]?.en}`);
  };
  const setReqStatus = async (id: number, status: string) => {
    const r = await fetch("/api/sell-requests", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    const o = await r.json();
    setReqs((rs) => rs.map((x) => (x.id === id ? o : x)));
  };

  const tabs = [
    ["overview", lang === "hi" ? "सारांश" : "Overview"],
    ["inventory", lang === "hi" ? "इन्वेंटरी" : "Inventory"],
    ["orders", lang === "hi" ? "ऑर्डर" : "Orders"],
    ["farmers", lang === "hi" ? "किसान रिक्वेस्ट" : "Farmer Requests"],
  ] as const;

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <div className="flex items-start justify-between">
        <PageTitle title={mode === "admin" ? "Admin Panel" : lang === "hi" ? "सेलर डैशबोर्ड" : "Seller Dashboard"} sub={`${lang === "hi" ? "नमस्ते" : "Hello"}, ${user.name} 👋`} />
        <button onClick={load} className="btn-outline py-2 text-sm"><RefreshCw size={14} /> {lang === "hi" ? "रिफ्रेश" : "Refresh"}</button>
      </div>

      <div className="no-scrollbar mb-5 flex gap-2 overflow-x-auto">
        {tabs.map(([id, l]) => (
          <button key={id} onClick={() => setTab(id)} className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold ${tab === id ? "bg-green-700 text-white" : "bg-white text-gray-700 border border-green-100"}`}>{l}</button>
        ))}
      </div>

      {loading ? <Spinner /> : (
        <>
          {tab === "overview" && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                {[
                  { icon: IndianRupee, l: lang === "hi" ? "कुल कमाई" : "Earnings", v: `₹${revenue.toFixed(0)}`, c: "text-green-700" },
                  { icon: TrendingUp, l: lang === "hi" ? "पेंडिंग" : "Pending value", v: `₹${pendingRevenue.toFixed(0)}`, c: "text-accent-dark" },
                  { icon: Package, l: lang === "hi" ? "आज के ऑर्डर" : "Today's orders", v: todayOrders.length, c: "text-blue-700" },
                  { icon: AlertTriangle, l: lang === "hi" ? "कम स्टॉक" : "Low stock", v: lowStock.length, c: "text-sale" },
                ].map(({ icon: Icon, l, v, c }) => (
                  <div key={l} className="card p-4"><Icon className={c} size={22} /><div className="mt-2 text-2xl font-bold">{v}</div><div className="text-xs text-gray-500">{l}</div></div>
                ))}
              </div>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="card p-4">
                  <h3 className="flex items-center gap-2 font-bold"><Percent size={16} className="text-green-700" /> {lang === "hi" ? "कमीशन और पेआउट" : "Commission & Payout"}</h3>
                  <div className="mt-3 space-y-1 text-sm">
                    <div className="flex justify-between"><span>Gross (delivered)</span><span>₹{revenue.toFixed(0)}</span></div>
                    <div className="flex justify-between text-gray-500"><span>Platform commission ({COMMISSION * 100}%)</span><span>−₹{(revenue * COMMISSION).toFixed(0)}</span></div>
                    <div className="flex justify-between border-t pt-1 font-bold text-green-700"><span>Net payout</span><span>₹{(revenue * (1 - COMMISSION)).toFixed(0)}</span></div>
                  </div>
                </div>
                <div className="card p-4">
                  <h3 className="font-bold">📈 {lang === "hi" ? "लोकप्रिय सब्ज़ियाँ" : "Popular products"}</h3>
                  <ul className="mt-2 space-y-1 text-sm">{popular.map((p) => <li key={p.id} className="flex justify-between"><span>{p.name}</span><span className="text-gray-500">{p.sold} sold</span></li>)}</ul>
                  <p className="mt-2 text-xs text-gray-500">Peak hour: {peakHour ? `${peakHour}:00` : "—"}</p>
                </div>
                <div className="card p-4">
                  <h3 className="flex items-center gap-2 font-bold"><AlertTriangle size={16} className="text-sale" /> {lang === "hi" ? "कम स्टॉक अलर्ट" : "Low stock alerts"}</h3>
                  {lowStock.length === 0 ? <p className="mt-2 text-sm text-gray-500">All good ✅</p> : <ul className="mt-2 space-y-1 text-sm">{lowStock.map((p) => <li key={p.id} className="flex justify-between"><span>{p.name}</span><span className="font-semibold text-sale">{p.stock} {p.unit}</span></li>)}</ul>}
                </div>
              </div>
              {mode === "admin" && (
                <div className="card p-4">
                  <h3 className="flex items-center gap-2 font-bold"><Users size={16} className="text-green-700" /> Admin summary</h3>
                  <div className="mt-2 grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
                    <div>Products: <b>{products.length}</b></div>
                    <div>Orders: <b>{orders.length}</b></div>
                    <div>Farmer requests: <b>{reqs.length}</b></div>
                    <div>Commission rate: <b>{COMMISSION * 100}%</b></div>
                  </div>
                  <p className="mt-2 text-xs text-gray-500">Active coupons: FRESH10, SABZI50, WELCOME · Banners & promotions configured on homepage.</p>
                </div>
              )}
            </div>
          )}

          {tab === "inventory" && (
            <div>
              <button onClick={() => setShowAdd((s) => !s)} className="btn-primary mb-4"><Plus size={16} /> {lang === "hi" ? "नई सब्ज़ी जोड़ें" : "Add vegetable"}</button>
              {showAdd && (
                <form onSubmit={addProduct} className="card mb-4 grid gap-3 p-4 sm:grid-cols-3">
                  <input required placeholder="Name (e.g. Lauki)" className="input" value={np.name} onChange={(e) => setNp({ ...np, name: e.target.value })} />
                  <input placeholder="Hindi name (लौकी)" className="input" value={np.nameHi} onChange={(e) => setNp({ ...np, nameHi: e.target.value })} />
                  <select className="input" value={np.categorySlug} onChange={(e) => setNp({ ...np, categorySlug: e.target.value })}>{["leafy", "root", "seasonal", "organic", "exotic", "fruits"].map((c) => <option key={c}>{c}</option>)}</select>
                  <input required type="number" placeholder="Price ₹" className="input" value={np.price} onChange={(e) => setNp({ ...np, price: e.target.value })} />
                  <select className="input" value={np.unit} onChange={(e) => setNp({ ...np, unit: e.target.value })}><option value="kg">kg</option><option value="piece">piece</option><option value="bunch">bunch</option><option value="crate">crate</option></select>
                  <input required type="number" placeholder="Stock" className="input" value={np.stock} onChange={(e) => setNp({ ...np, stock: e.target.value })} />
                  <input type="number" placeholder="Wholesale price ₹" className="input" value={np.wholesalePrice} onChange={(e) => setNp({ ...np, wholesalePrice: e.target.value })} />
                  <input type="number" placeholder="Wholesale min qty" className="input" value={np.wholesaleMinQty} onChange={(e) => setNp({ ...np, wholesaleMinQty: e.target.value })} />
                  <select className="input" value={np.image} onChange={(e) => setNp({ ...np, image: e.target.value })}>{["tomato", "potato", "bhindi", "cauliflower", "spinach", "capsicum", "karela", "onion", "cabbage"].map((i) => <option key={i} value={`/images/${i}.jpg`}>{i} photo</option>)}</select>
                  <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={np.organic} onChange={(e) => setNp({ ...np, organic: e.target.checked })} /> Organic</label>
                  <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={np.seasonal} onChange={(e) => setNp({ ...np, seasonal: e.target.checked })} /> Seasonal</label>
                  <button className="btn-primary">Save</button>
                </form>
              )}
              <div className="card overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-green-50 text-left text-xs uppercase text-gray-600"><tr><th className="p-3">Product</th><th className="p-3">Price</th><th className="p-3">Stock</th><th className="p-3">Sold</th><th className="p-3"></th></tr></thead>
                  <tbody>
                    {products.map((p) => (
                      <tr key={p.id} className="border-t">
                        <td className="p-3 font-medium">{p.name} <span className="text-gray-400">({p.nameHi})</span>{p.stock <= 10 && <span className="ml-1 rounded bg-red-50 px-1 text-[10px] text-sale">LOW</span>}</td>
                        <td className="p-3"><input type="number" defaultValue={p.price} onBlur={(e) => Number(e.target.value) !== p.price && updatePrice(p.id, Number(e.target.value))} className="input w-24 py-1" /> <span className="text-gray-400">/{p.unit}</span></td>
                        <td className="p-3"><div className="flex items-center gap-1"><button onClick={() => updateStock(p.id, p.stock - 5)} className="rounded border px-2">−5</button><span className="min-w-10 text-center font-semibold">{p.stock}</span><button onClick={() => updateStock(p.id, p.stock + 5)} className="rounded border px-2">+5</button></div></td>
                        <td className="p-3">{p.sold}</td>
                        <td className="p-3"><button onClick={() => removeProduct(p.id)} className="text-gray-400 hover:text-sale"><Trash2 size={16} /></button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === "orders" && (
            orders.length === 0 ? <EmptyState emoji="📭" title="No orders yet" /> : (
              <ul className="space-y-3">
                {orders.map((o) => (
                  <li key={o.id} className="card p-4">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="font-bold">#{o.orderNumber} <span className={`ml-2 rounded-full px-2 py-0.5 text-xs ${STATUS_LABEL[o.status]?.cls}`}>{STATUS_LABEL[o.status]?.[lang]}</span></div>
                        <div className="text-xs text-gray-500">{new Date(o.createdAt).toLocaleString("en-IN")} · {o.customerName} · {o.phone} · {o.area} · {o.paymentMethod.toUpperCase()}</div>
                        <div className="mt-1 text-sm text-gray-700">{o.items.map((i) => `${i.name}×${i.qty}`).join(", ")}</div>
                      </div>
                      <div className="text-lg font-bold">₹{Number(o.total).toFixed(0)}</div>
                    </div>
                    {!["delivered", "cancelled"].includes(o.status) && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {o.status === "placed" && <><button onClick={() => setOrderStatus(o.id, "accepted")} className="btn-primary py-1.5 text-xs">Accept</button><button onClick={() => setOrderStatus(o.id, "cancelled")} className="rounded-xl border border-sale px-3 py-1.5 text-xs font-semibold text-sale">Reject</button></>}
                        {o.status !== "placed" && (() => { const next = STATUS_FLOW[STATUS_FLOW.indexOf(o.status as (typeof STATUS_FLOW)[number]) + 1]; return next ? <button onClick={() => setOrderStatus(o.id, next)} className="btn-primary py-1.5 text-xs">Mark {STATUS_LABEL[next].en}</button> : null; })()}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            )
          )}

          {tab === "farmers" && (
            reqs.length === 0 ? <EmptyState emoji="🚜" title="No farmer requests yet" sub="Farmers can list sabzi from the Sell page" /> : (
              <ul className="space-y-3">
                {reqs.map((r) => (
                  <li key={r.id} className="card p-4">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2 font-bold"><Tractor size={16} className="text-green-700" /> {r.vegetable} — {r.quantity} {r.unit} @ ₹{Number(r.expectedPrice).toFixed(0)}/{r.unit} {r.organic && <span className="rounded bg-lime-100 px-1.5 text-[10px] text-green-800">ORGANIC</span>}</div>
                        <div className="text-sm text-gray-600">{r.farmerName} · <a href={`tel:${r.phone}`} className="text-green-700">{r.phone}</a> · {r.village}</div>
                        <div className="text-xs text-gray-400">{new Date(r.createdAt).toLocaleString("en-IN")} · Total ≈ ₹{Number(r.quantity) * Number(r.expectedPrice)}</div>
                      </div>
                      <select value={r.status} onChange={(e) => setReqStatus(r.id, e.target.value)} className="input w-auto text-xs">
                        <option value="pending">Pending</option><option value="visit_scheduled">Visit scheduled</option><option value="purchased">Purchased</option><option value="rejected">Rejected</option>
                      </select>
                    </div>
                  </li>
                ))}
              </ul>
            )
          )}
        </>
      )}
    </div>
  );
}
