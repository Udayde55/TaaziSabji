"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Lang = "en" | "hi";

export type SessionUser = {
  id: number;
  name: string;
  email: string;
  role: "buyer" | "seller" | "admin";
  phone?: string | null;
  area?: string | null;
};

type AppState = {
  lang: Lang;
  setLang: (l: Lang) => void;
  location: string;
  setLocation: (l: string) => void;
  user: SessionUser | null;
  setUser: (u: SessionUser | null) => void;
  wishlist: number[];
  toggleWishlist: (id: number) => void;
};

export const useApp = create<AppState>()(
  persist(
    (set) => ({
      lang: "en",
      setLang: (lang) => set({ lang }),
      location: "Khutpipariya, MP",
      setLocation: (location) => set({ location }),
      user: null,
      setUser: (user) => set({ user }),
      wishlist: [],
      toggleWishlist: (id) =>
        set((s) => ({
          wishlist: s.wishlist.includes(id) ? s.wishlist.filter((x) => x !== id) : [...s.wishlist, id],
        })),
    }),
    { name: "taazisabzi-app" }
  )
);
