"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { User, Package, Heart, LogOut, LayoutDashboard, Tractor, Phone, Languages, Save } from "lucide-react";
import { useApp } from "@/store/app";
import { useT } from "@/lib/i18n";
import { EmptyState, Spinner } from "@/components/ui/Common";
import { toast } from "@/components/ui/Toaster";

export default function ProfilePage() {
  const router = useRouter();
  const { user, setUser, lang, setLang, wishlist } = useApp();
  const { t } = useT();
  const [mounted, setMounted] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", area: "", address: "" });
  useEffect(() => {
    setMounted(true);
    if (user) setForm({ name: user.name, phone: user.phone ?? "", area: user.area ?? "", address: "" });
  }, [user]);

  if (!mounted) return <Spinner />;
  if (!user)
    return (
      <div className="mx-auto max-w-md px-4 py-6">
        <EmptyState emoji="👋" title={lang === "hi" ? "नमस्ते!" : "Namaste!"} sub={lang === "hi" ? "अपने ऑर्डर और प्रोफ़ाइल देखने के लिए लॉगिन करें" : "Login to see your profile & orders"} action={<div className="flex gap-2"><Link href="/login" className="btn-primary">{t("login")}</Link><Link href="/register" className="btn-outline">{t("register")}</Link></div>} />
        <button onClick={() => setLang(lang === "en" ? "hi" : "en")} className="btn-outline mx-auto flex"><Languages size={16} /> {lang === "en" ? "हिंदी में देखें" : "Switch to English"}</button>
      </div>
    );

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/auth", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: user.id, ...form }) });
    if (res.ok) {
      setUser(await res.json());
      toast(lang === "hi" ? "प्रोफ़ाइल सेव हुई" : "Profile saved");
    }
  };

  const links = [
    { href: "/orders", icon: Package, l: lang === "hi" ? "मेरे ऑर्डर" : "My Orders" },
    { href: "/products", icon: Heart, l: `${lang === "hi" ? "पसंदीदा" : "Wishlist"} (${wishlist.length})` },
    { href: "/sell", icon: Tractor, l: lang === "hi" ? "अपनी सब्ज़ी बेचें" : "Sell your Sabzi" },
    ...(user.role === "seller" || user.role === "admin" ? [{ href: "/seller", icon: LayoutDashboard, l: lang === "hi" ? "सेलर डैशबोर्ड" : "Seller Dashboard" }] : []),
    ...(user.role === "admin" ? [{ href: "/admin", icon: LayoutDashboard, l: "Admin Panel" }] : []),
    { href: "/contact", icon: Phone, l: t("contact") },
  ];

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <div className="card flex items-center gap-4 p-5">
        <span className="grid h-14 w-14 place-items-center rounded-full bg-green-700 text-white"><User size={28} /></span>
        <div>
          <h1 className="text-xl font-bold">{user.name}</h1>
          <p className="text-sm text-gray-500">{user.email} · <span className="rounded bg-green-50 px-1.5 py-0.5 text-xs font-semibold capitalize text-green-700">{user.role}</span></p>
        </div>
        <button onClick={() => setLang(lang === "en" ? "hi" : "en")} className="ml-auto rounded-lg border px-2 py-1 text-xs font-semibold"><Languages size={14} className="inline" /> {lang === "en" ? "हिं" : "EN"}</button>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3">
        {links.map(({ href, icon: Icon, l }) => (
          <Link key={href + l} href={href} className="card flex items-center gap-2 p-4 text-sm font-medium hover:shadow-md"><Icon size={18} className="text-green-700" /> {l}</Link>
        ))}
      </div>

      <form onSubmit={save} className="card mt-4 space-y-3 p-5">
        <h2 className="font-bold">{lang === "hi" ? "प्रोफ़ाइल अपडेट करें" : "Update Profile"}</h2>
        <div><label className="label">{lang === "hi" ? "नाम" : "Name"}</label><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
        <div><label className="label">{lang === "hi" ? "मोबाइल" : "Phone"}</label><input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
        <div><label className="label">{lang === "hi" ? "क्षेत्र" : "Area"}</label><input className="input" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} /></div>
        <div><label className="label">{lang === "hi" ? "पता" : "Address"}</label><textarea className="input" rows={2} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
        <button className="btn-primary"><Save size={16} /> {lang === "hi" ? "सेव करें" : "Save"}</button>
      </form>

      <button onClick={() => { setUser(null); router.push("/"); }} className="mt-4 flex items-center gap-2 text-sm font-semibold text-sale"><LogOut size={16} /> {t("logout")}</button>
    </div>
  );
}
