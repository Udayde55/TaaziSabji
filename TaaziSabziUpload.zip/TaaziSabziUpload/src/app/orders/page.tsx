"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Package, Search, RotateCcw } from "lucide-react";
import { useApp } from "@/store/app";
import { useCart } from "@/store/cart";
import { useT } from "@/lib/i18n";
import { EmptyState, PageTitle, Spinner } from "@/components/ui/Common";
import { toast } from "@/components/ui/Toaster";
import { STATUS_LABEL } from "@/lib/status";

type Item = { id: number; name: string; price: number; qty: number; unit: string; image: string };
type Order = { id: number; orderNumber: string; status: string; total: string; createdAt: string; items: Item[]; deliverySlot: string; paymentMethod: string };

export default function OrdersPage() {
  const { user } = useApp();
  const add = useCart((s) => s.add);
  const { t, lang } = useT();
  const [phone, setPhone] = useState("");
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [mounted, setMounted] = useState(false);

  const load = async (ph: string) => {
    if (!ph) return setOrders([]);
    const r = await fetch(`/api/orders?phone=${encodeURIComponent(ph)}`);
    setOrders(await r.json());
  };

  useEffect(() => {
    setMounted(true);
    const saved = user?.phone || localStorage.getItem("ts-last-phone") || "";
    setPhone(saved);
    load(saved);
  }, [user]);

  const search = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem("ts-last-phone", phone);
    setOrders(null);
    load(phone);
  };

  const reorder = async (o: Order) => {
    const res = await fetch("/api/products");
    const all: { id: number; slug: string; name: string; nameHi: string; image: string; price: number; unit: string; stock: number }[] = await res.json();
    o.items.forEach((it) => {
      const p = all.find((x) => x.id === it.id);
      if (p && p.stock > 0) add({ id: p.id, slug: p.slug, name: p.name, nameHi: p.nameHi, image: p.image, price: p.price, unit: p.unit, stock: p.stock }, it.qty);
    });
    toast(lang === "hi" ? "कार्ट में जोड़ा गया" : "Items added to cart");
  };

  if (!mounted) return <Spinner />;

  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <PageTitle title={t("orders")} sub={lang === "hi" ? "मोबाइल नंबर से अपने ऑर्डर देखें" : "Find your orders by phone number"} />
      <form onSubmit={search} className="mb-5 flex gap-2">
        <div className="flex flex-1 items-center rounded-xl border border-gray-200 bg-white px-3"><Search size={16} className="text-gray-400" /><input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder={lang === "hi" ? "मोबाइल नंबर" : "Phone number"} className="h-11 w-full bg-transparent px-2 text-sm outline-none" /></div>
        <button className="btn-primary">{lang === "hi" ? "खोजें" : "Find"}</button>
      </form>

      {orders === null ? (
        <Spinner />
      ) : orders.length === 0 ? (
        <EmptyState emoji="📦" title={lang === "hi" ? "कोई ऑर्डर नहीं" : "No orders yet"} sub={lang === "hi" ? "अपना पहला ऑर्डर करें" : "Place your first fresh order"} action={<Link href="/products" className="btn-primary">{t("shopNow")}</Link>} />
      ) : (
        <ul className="space-y-3">
          {orders.map((o) => (
            <li key={o.id} className="card p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <Link href={`/orders/${o.orderNumber}`} className="flex items-center gap-2 font-bold text-green-800"><Package size={18} /> #{o.orderNumber}</Link>
                  <div className="text-xs text-gray-500">{new Date(o.createdAt).toLocaleString("en-IN")} · {o.paymentMethod.toUpperCase()}</div>
                </div>
                <span className={`rounded-full px-3 py-1 text-xs font-semibold ${STATUS_LABEL[o.status]?.cls ?? "bg-gray-100"}`}>{STATUS_LABEL[o.status]?.[lang] ?? o.status}</span>
              </div>
              <p className="mt-2 line-clamp-1 text-sm text-gray-600">{o.items.map((i) => `${i.name} × ${i.qty}`).join(", ")}</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="font-bold">₹{Number(o.total).toFixed(0)}</span>
                <div className="flex gap-2">
                  <button onClick={() => reorder(o)} className="btn-outline py-1.5 text-xs"><RotateCcw size={14} /> {lang === "hi" ? "फिर से ऑर्डर" : "Reorder"}</button>
                  <Link href={`/orders/${o.orderNumber}`} className="btn-primary py-1.5 text-xs">{lang === "hi" ? "ट्रैक करें" : "Track"}</Link>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
