"use client";

import Link from "next/link";
import Image from "next/image";
import { use, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { CheckCircle2, Circle, MessageCircle, Phone, MapPin } from "lucide-react";
import { useT } from "@/lib/i18n";
import { Spinner, EmptyState } from "@/components/ui/Common";
import { STATUS_FLOW, STATUS_LABEL, SLOT_LABEL } from "@/lib/status";
import { CONTACT } from "@/components/layout/Footer";

type Item = { id: number; name: string; price: number; qty: number; unit: string; image: string };
type Order = {
  id: number; orderNumber: string; status: string; total: string; subtotal: string; deliveryCharge: string; discount: string;
  createdAt: string; items: Item[]; deliverySlot: string; paymentMethod: string; paymentStatus: string; address: string; area: string; customerName: string; phone: string;
};

export default function OrderDetailPage({ params }: { params: Promise<{ orderNumber: string }> }) {
  const { orderNumber } = use(params);
  const sp = useSearchParams();
  const isNew = sp.get("new") === "1";
  const { lang } = useT();
  const [order, setOrder] = useState<Order | null | undefined>(undefined);

  useEffect(() => {
    const load = () => fetch(`/api/orders?orderNumber=${orderNumber}`).then((r) => r.json()).then((rows) => setOrder(rows[0] ?? null));
    load();
    const id = setInterval(load, 10000); // live tracking poll
    return () => clearInterval(id);
  }, [orderNumber]);

  if (order === undefined) return <Spinner />;
  if (!order) return <EmptyState emoji="🔍" title="Order not found" action={<Link href="/orders" className="btn-primary">My Orders</Link>} />;

  const idx = STATUS_FLOW.indexOf(order.status as (typeof STATUS_FLOW)[number]);
  const waText = encodeURIComponent(`Namaste TaaziSabzi! Mera order #${order.orderNumber} ke bare me jaankari chahiye.`);

  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      {isNew && (
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="card mb-5 border-green-500 bg-green-50 p-5 text-center">
          <div className="text-5xl">🎉</div>
          <h2 className="mt-2 text-xl font-bold text-green-800">{lang === "hi" ? "ऑर्डर कन्फर्म हो गया!" : "Order Confirmed!"}</h2>
          <p className="text-sm text-gray-600">{lang === "hi" ? "कन्फर्मेशन SMS / WhatsApp / Email पर भेज दिया गया है।" : "Confirmation sent via SMS / WhatsApp / Email."}</p>
        </motion.div>
      )}

      <div className="card p-5">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold">#{order.orderNumber}</h1>
            <p className="text-xs text-gray-500">{new Date(order.createdAt).toLocaleString("en-IN")}</p>
          </div>
          <span className={`rounded-full px-3 py-1 text-xs font-semibold ${STATUS_LABEL[order.status]?.cls}`}>{STATUS_LABEL[order.status]?.[lang]}</span>
        </div>

        {order.status !== "cancelled" && (
          <ol className="mt-6 grid grid-cols-5 gap-1">
            {STATUS_FLOW.map((s, i) => (
              <li key={s} className="flex flex-col items-center text-center">
                <div className="relative flex w-full items-center justify-center">
                  {i > 0 && <span className={`absolute left-0 right-1/2 top-1/2 h-1 -translate-y-1/2 ${i <= idx ? "bg-green-600" : "bg-gray-200"}`} />}
                  {i < STATUS_FLOW.length - 1 && <span className={`absolute left-1/2 right-0 top-1/2 h-1 -translate-y-1/2 ${i < idx ? "bg-green-600" : "bg-gray-200"}`} />}
                  {i <= idx ? <CheckCircle2 className="relative z-10 rounded-full bg-white text-green-600" size={26} /> : <Circle className="relative z-10 rounded-full bg-white text-gray-300" size={26} />}
                </div>
                <span className={`mt-1 text-[10px] leading-tight md:text-xs ${i <= idx ? "font-semibold text-green-800" : "text-gray-400"}`}>{STATUS_LABEL[s][lang]}</span>
              </li>
            ))}
          </ol>
        )}

        <div className="mt-6 grid gap-4 text-sm md:grid-cols-2">
          <div className="rounded-xl bg-green-50 p-3">
            <div className="font-semibold">{lang === "hi" ? "डिलीवरी" : "Delivery"}</div>
            <div className="text-gray-600">{SLOT_LABEL[order.deliverySlot]?.[lang] ?? order.deliverySlot}</div>
            <div className="mt-1 flex items-start gap-1 text-gray-600"><MapPin size={14} className="mt-0.5 shrink-0" /> {order.address}, {order.area}</div>
          </div>
          <div className="rounded-xl bg-green-50 p-3">
            <div className="font-semibold">{lang === "hi" ? "भुगतान" : "Payment"}</div>
            <div className="text-gray-600">{order.paymentMethod.toUpperCase()} · {order.paymentStatus === "paid" ? (lang === "hi" ? "भुगतान हुआ" : "Paid") : lang === "hi" ? "डिलीवरी पर भुगतान" : "Pay on delivery"}</div>
            <div className="text-gray-600">{order.customerName} · {order.phone}</div>
          </div>
        </div>

        <ul className="mt-5 divide-y">
          {order.items.map((i) => (
            <li key={i.id} className="flex items-center gap-3 py-2">
              <div className="relative h-12 w-12 overflow-hidden rounded-lg bg-green-50"><Image src={i.image} alt={i.name} fill sizes="48px" className="object-cover" /></div>
              <div className="flex-1 text-sm"><div className="font-medium">{i.name}</div><div className="text-gray-500">₹{i.price} × {i.qty} {i.unit}</div></div>
              <div className="font-semibold">₹{(i.price * i.qty).toFixed(0)}</div>
            </li>
          ))}
        </ul>
        <div className="mt-3 space-y-1 border-t pt-3 text-sm">
          <div className="flex justify-between"><span>Subtotal</span><span>₹{Number(order.subtotal).toFixed(0)}</span></div>
          <div className="flex justify-between"><span>Delivery</span><span>₹{Number(order.deliveryCharge).toFixed(0)}</span></div>
          {Number(order.discount) > 0 && <div className="flex justify-between text-green-700"><span>Discount</span><span>−₹{Number(order.discount).toFixed(0)}</span></div>}
          <div className="flex justify-between text-base font-bold"><span>Total</span><span>₹{Number(order.total).toFixed(0)}</span></div>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <a href={`https://wa.me/${CONTACT.phoneRaw}?text=${waText}`} target="_blank" rel="noreferrer" className="btn-primary bg-[#25D366] hover:bg-[#1ebe5a] text-sm"><MessageCircle size={16} /> WhatsApp Support</a>
          <a href={`tel:${CONTACT.phone.replace(/\s/g, "")}`} className="btn-outline text-sm"><Phone size={16} /> {CONTACT.phone}</a>
          <Link href="/orders" className="btn-outline text-sm">{lang === "hi" ? "सभी ऑर्डर" : "All orders"}</Link>
        </div>
        <p className="mt-4 text-xs text-gray-500">{lang === "hi" ? "ताज़गी गारंटी: सब्ज़ी पसंद न आए तो डिलीवरी के 2 घंटे के अंदर WhatsApp पर फोटो भेजें, हम बदल देंगे।" : "Freshness guarantee: if not happy, send a photo on WhatsApp within 2 hours of delivery for replacement."}</p>
      </div>
    </div>
  );
}
