"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Minus, Plus, Trash2, ArrowRight, Truck } from "lucide-react";
import { useCart } from "@/store/cart";
import { useT, unitLabel } from "@/lib/i18n";
import { EmptyState, PageTitle, Spinner } from "@/components/ui/Common";

export default function CartPage() {
  const { items, setQty, remove, clear } = useCart();
  const { t, lang } = useT();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return <Spinner />;

  const subtotal = items.reduce((n, i) => n + i.qty * i.price, 0);
  const delivery = subtotal >= 299 ? 0 : 19;

  if (items.length === 0)
    return (
      <div className="mx-auto max-w-7xl px-4 py-6">
        <EmptyState emoji="🧺" title={t("emptyCart")} sub={t("emptyCartSub")} action={<Link href="/products" className="btn-primary">{t("shopNow")}</Link>} />
      </div>
    );

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <PageTitle title={`${t("cart")} (${items.length})`} />
      <div className="grid gap-6 md:grid-cols-3">
        <div className="space-y-3 md:col-span-2">
          {items.map((i) => (
            <div key={i.id} className="card flex items-center gap-3 p-3">
              <Link href={`/products/${i.slug}`} className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-green-50">
                <Image src={i.image} alt={i.name} fill sizes="80px" className="object-cover" />
              </Link>
              <div className="min-w-0 flex-1">
                <div className="truncate font-semibold">{lang === "hi" ? i.nameHi : i.name}</div>
                <div className="text-sm text-gray-500">₹{i.price}/{unitLabel(i.unit, lang)}</div>
                <div className="mt-2 flex items-center gap-3">
                  <div className="flex items-center rounded-lg border border-green-700 text-green-700">
                    <button onClick={() => setQty(i.id, i.qty - 1)} className="px-2 py-1"><Minus size={14} /></button>
                    <span className="min-w-6 text-center text-sm font-bold">{i.qty}</span>
                    <button onClick={() => setQty(i.id, i.qty + 1)} className="px-2 py-1"><Plus size={14} /></button>
                  </div>
                  <button onClick={() => remove(i.id)} className="text-gray-400 hover:text-sale"><Trash2 size={16} /></button>
                </div>
              </div>
              <div className="font-bold text-green-800">₹{(i.qty * i.price).toFixed(0)}</div>
            </div>
          ))}
          <button onClick={clear} className="text-sm text-gray-500 underline">{lang === "hi" ? "कार्ट खाली करें" : "Clear cart"}</button>
        </div>

        <div className="card h-fit p-5 md:sticky md:top-24">
          <h3 className="font-bold">{lang === "hi" ? "बिल विवरण" : "Bill Details"}</h3>
          <div className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between"><span>{t("subtotal")}</span><span>₹{subtotal.toFixed(0)}</span></div>
            <div className="flex justify-between"><span>{t("delivery")}</span><span className={delivery === 0 ? "font-semibold text-green-700" : ""}>{delivery === 0 ? t("free") : `₹${delivery}`}</span></div>
            {delivery > 0 && (
              <p className="flex items-center gap-1 rounded-lg bg-green-50 px-2 py-1.5 text-xs text-green-800">
                <Truck size={14} /> {lang === "hi" ? `₹${299 - subtotal} और जोड़ें, फ्री डिलीवरी पाएं` : `Add ₹${299 - subtotal} more for FREE delivery`}
              </p>
            )}
            <div className="flex justify-between border-t pt-2 text-base font-bold"><span>{t("total")}</span><span>₹{(subtotal + delivery).toFixed(0)}</span></div>
          </div>
          <Link href="/checkout" className="btn-primary mt-4 w-full py-3">
            {t("checkout")} <ArrowRight size={18} />
          </Link>
        </div>
      </div>
    </div>
  );
}
