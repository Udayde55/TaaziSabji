import Dashboard from "@/components/dashboard/Dashboard";

export default function SellerPage() {
  return <Dashboard mode="seller" />;
}
