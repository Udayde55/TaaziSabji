"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Timer, Truck, CalendarDays, Smartphone, CreditCard, Landmark, Banknote, Wallet, Tag, CheckCircle2 } from "lucide-react";
import { useCart } from "@/store/cart";
import { useApp } from "@/store/app";
import { useT } from "@/lib/i18n";
import { EmptyState, PageTitle, Spinner } from "@/components/ui/Common";
import { toast } from "@/components/ui/Toaster";

const COUPONS: Record<string, { type: "percent" | "flat"; value: number; min: number }> = {
  FRESH10: { type: "percent", value: 10, min: 199 },
  SABZI50: { type: "flat", value: 50, min: 499 },
  WELCOME: { type: "flat", value: 30, min: 149 },
};

export default function CheckoutPage() {
  const router = useRouter();
  const { items, clear } = useCart();
  const { user, location } = useApp();
  const { t, lang } = useT();
  const [mounted, setMounted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState<string | null>(null);
  const [form, setForm] = useState({ customerName: "", phone: "", email: "", address: "", area: "", notes: "", deliverySlot: "sameday", paymentMethod: "upi" });

  useEffect(() => {
    setMounted(true);
    setForm((f) => ({ ...f, customerName: user?.name ?? "", phone: user?.phone ?? "", email: user?.email ?? "", area: user?.area ?? location }));
  }, [user, location]);

  if (!mounted) return <Spinner />;
  if (items.length === 0)
    return (
      <div className="mx-auto max-w-7xl px-4 py-6">
        <EmptyState emoji="🧺" title={t("emptyCart")} sub={t("emptyCartSub")} action={<Link href="/products" className="btn-primary">{t("shopNow")}</Link>} />
      </div>
    );

  const subtotal = items.reduce((n, i) => n + i.qty * i.price, 0);
  const delivery = form.deliverySlot === "express10" ? 29 : subtotal >= 299 ? 0 : 19;
  let discount = 0;
  if (applied && COUPONS[applied] && subtotal >= COUPONS[applied].min) {
    const c = COUPONS[applied];
    discount = c.type === "percent" ? Math.round((subtotal * c.value) / 100) : c.value;
  }
  const total = Math.max(0, subtotal + delivery - discount);

  const applyCoupon = () => {
    const code = coupon.trim().toUpperCase();
    if (!COUPONS[code]) return toast(lang === "hi" ? "अमान्य कूपन" : "Invalid coupon", "error");
    if (subtotal < COUPONS[code].min) return toast(`${lang === "hi" ? "न्यूनतम ऑर्डर" : "Min order"} ₹${COUPONS[code].min}`, "error");
    setApplied(code);
    toast(`${code} ${lang === "hi" ? "लागू हुआ" : "applied"} 🎉`);
  };

  const slots = [
    { id: "express10", icon: Timer, label: lang === "hi" ? "10 मिनट एक्सप्रेस" : "10-Min Express", sub: "+₹29 · Khutpipariya only" },
    { id: "sameday", icon: Truck, label: lang === "hi" ? "आज ही (सेम डे)" : "Same Day", sub: lang === "hi" ? "शाम 4–8 बजे" : "4 PM – 8 PM" },
    { id: "nextday", icon: CalendarDays, label: lang === "hi" ? "कल सुबह" : "Next Day Morning", sub: lang === "hi" ? "सुबह 7–10 बजे" : "7 AM – 10 AM" },
  ];
  const payments = [
    { id: "upi", icon: Smartphone, label: "UPI (GPay / PhonePe / Paytm)" },
    { id: "card", icon: CreditCard, label: lang === "hi" ? "डेबिट / क्रेडिट कार्ड" : "Debit / Credit Card" },
    { id: "netbanking", icon: Landmark, label: lang === "hi" ? "नेट बैंकिंग" : "Net Banking" },
    { id: "wallet", icon: Wallet, label: lang === "hi" ? "वॉलेट" : "Wallet" },
    { id: "cod", icon: Banknote, label: lang === "hi" ? "कैश ऑन डिलीवरी" : "Cash on Delivery" },
  ];

  const placeOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, coupon: applied, items: items.map((i) => ({ id: i.id, qty: i.qty })) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      clear();
      router.push(`/orders/${data.orderNumber}?new=1`);
    } catch (err) {
      toast((err as Error).message, "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <PageTitle title={t("checkout")} sub={lang === "hi" ? "पता, डिलीवरी समय और भुगतान चुनें" : "Address, delivery slot & payment"} />
      <form onSubmit={placeOrder} className="grid gap-6 md:grid-cols-3">
        <div className="space-y-5 md:col-span-2">
          <div className="card p-5">
            <h3 className="mb-3 font-bold">1. {lang === "hi" ? "डिलीवरी पता" : "Delivery Address"}</h3>
            <div className="grid gap-3 sm:grid-cols-2">
              <div><label className="label">{lang === "hi" ? "नाम *" : "Full name *"}</label><input required className="input" value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} /></div>
              <div><label className="label">{lang === "hi" ? "मोबाइल *" : "Phone *"}</label><input required type="tel" pattern="[0-9+ ]{10,14}" className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div><label className="label">Email</label><input type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><label className="label">{lang === "hi" ? "क्षेत्र / गाँव" : "Area / Village"}</label><input className="input" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} /></div>
              <div className="sm:col-span-2"><label className="label">{lang === "hi" ? "पूरा पता *" : "Full address *"}</label><textarea required rows={2} className="input" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
              <div className="sm:col-span-2"><label className="label">{lang === "hi" ? "नोट (वैकल्पिक)" : "Notes (optional)"}</label><input className="input" placeholder={lang === "hi" ? "जैसे: छोटे टमाटर दें" : "e.g. small tomatoes please"} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
            </div>
          </div>

          <div className="card p-5">
            <h3 className="mb-3 font-bold">2. {lang === "hi" ? "डिलीवरी समय" : "Delivery Slot"}</h3>
            <div className="grid gap-2 sm:grid-cols-3">
              {slots.map(({ id, icon: Icon, label, sub }) => (
                <label key={id} className={`flex cursor-pointer items-center gap-3 rounded-xl border-2 p-3 ${form.deliverySlot === id ? "border-green-700 bg-green-50" : "border-gray-200"}`}>
                  <input type="radio" name="slot" className="hidden" checked={form.deliverySlot === id} onChange={() => setForm({ ...form, deliverySlot: id })} />
                  <Icon className="text-green-700" size={22} />
                  <div><div className="text-sm font-semibold">{label}</div><div className="text-xs text-gray-500">{sub}</div></div>
                </label>
              ))}
            </div>
          </div>

          <div className="card p-5">
            <h3 className="mb-3 font-bold">3. {lang === "hi" ? "भुगतान विधि" : "Payment Method"}</h3>
            <div className="grid gap-2 sm:grid-cols-2">
              {payments.map(({ id, icon: Icon, label }) => (
                <label key={id} className={`flex cursor-pointer items-center gap-3 rounded-xl border-2 p-3 ${form.paymentMethod === id ? "border-green-700 bg-green-50" : "border-gray-200"}`}>
                  <input type="radio" name="pay" className="hidden" checked={form.paymentMethod === id} onChange={() => setForm({ ...form, paymentMethod: id })} />
                  <Icon className="text-green-700" size={20} />
                  <span className="text-sm font-medium">{label}</span>
                  {form.paymentMethod === id && <CheckCircle2 size={18} className="ml-auto text-green-700" />}
                </label>
              ))}
            </div>
            <p className="mt-3 text-xs text-gray-500">🔒 {lang === "hi" ? "सुरक्षित भुगतान। ऑर्डर कन्फर्मेशन SMS / WhatsApp / Email पर भेजा जाएगा।" : "Secure payments. Order confirmation is sent via SMS / WhatsApp / Email."}</p>
          </div>
        </div>

        <div className="card h-fit p-5 md:sticky md:top-24">
          <h3 className="font-bold">{lang === "hi" ? "ऑर्डर सारांश" : "Order Summary"}</h3>
          <ul className="mt-3 max-h-48 space-y-1 overflow-auto text-sm">
            {items.map((i) => (
              <li key={i.id} className="flex justify-between"><span className="truncate">{lang === "hi" ? i.nameHi : i.name} × {i.qty}</span><span>₹{(i.qty * i.price).toFixed(0)}</span></li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2">
            <div className="flex flex-1 items-center rounded-xl border border-gray-200 px-3"><Tag size={16} className="text-gray-400" /><input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Coupon code" className="h-10 w-full bg-transparent px-2 text-sm uppercase outline-none" /></div>
            <button type="button" onClick={applyCoupon} className="btn-outline py-2 text-sm">Apply</button>
          </div>
          <div className="mt-3 space-y-2 border-t pt-3 text-sm">
            <div className="flex justify-between"><span>{t("subtotal")}</span><span>₹{subtotal.toFixed(0)}</span></div>
            <div className="flex justify-between"><span>{t("delivery")}</span><span>{delivery === 0 ? t("free") : `₹${delivery}`}</span></div>
            {discount > 0 && <div className="flex justify-between text-green-700"><span>Discount ({applied})</span><span>−₹{discount}</span></div>}
            <div className="flex justify-between border-t pt-2 text-base font-bold"><span>{t("total")}</span><span>₹{total.toFixed(0)}</span></div>
          </div>
          <button disabled={loading} className="btn-primary mt-4 w-full py-3">
            {loading ? "..." : `${t("placeOrder")} · ₹${total.toFixed(0)}`}
          </button>
        </div>
      </form>
    </div>
  );
}
