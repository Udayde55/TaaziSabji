"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Tractor, IndianRupee, MapPin, CheckCircle2, MessageCircle, Phone } from "lucide-react";
import { useT } from "@/lib/i18n";
import { toast } from "@/components/ui/Toaster";
import { CONTACT } from "@/components/layout/Footer";

const VEGS = ["Tamatar (टमाटर)", "Aalu (आलू)", "Bhindi (भिंडी)", "Phool Gobhi (फूल गोभी)", "Patta Gobhi (पत्ता गोभी)", "Shimla Mirch (शिमला मिर्च)", "Karela (करेला)", "Pyaz (प्याज़)", "Palak (पालक)", "Lauki (लौकी)", "Baingan (बैंगन)", "Other"];

export default function SellPage() {
  const { lang } = useT();
  const [done, setDone] = useState<null | { id: number }>(null);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ farmerName: "", phone: "", village: "", vegetable: VEGS[0], quantity: "", unit: "crate", expectedPrice: "", organic: false, notes: "" });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch("/api/sell-requests", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return toast(data.error, "error");
    setDone(data);
  };

  if (done)
    return (
      <div className="mx-auto max-w-md px-4 py-10">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="card p-6 text-center">
          <CheckCircle2 size={56} className="mx-auto text-green-600" />
          <h1 className="mt-3 text-xl font-bold">{lang === "hi" ? "धन्यवाद! आपकी सब्ज़ी लिस्ट हो गई" : "Thank you! Your sabzi is listed"}</h1>
          <p className="mt-2 text-sm text-gray-600">
            {lang === "hi" ? `रिक्वेस्ट नंबर #${done.id}। हमारी टीम आपको कॉल करेगी और आपकी लोकेशन पर आकर सब्ज़ी देखेगी। पसंद आने पर वहीं पेमेंट कर देंगे।` : `Request #${done.id}. Our team will call you and visit your location to inspect. If we like it, we pay you on the spot.`}
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <a href={`https://wa.me/${CONTACT.phoneRaw}?text=${encodeURIComponent(`Namaste! Maine sabzi bechne ki request #${done.id} daali hai.`)}`} target="_blank" rel="noreferrer" className="btn-primary bg-[#25D366] hover:bg-[#1ebe5a]"><MessageCircle size={16} /> WhatsApp</a>
            <button onClick={() => setDone(null)} className="btn-outline">{lang === "hi" ? "एक और लिस्ट करें" : "List another"}</button>
          </div>
        </motion.div>
      </div>
    );

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <div className="grid gap-6 md:grid-cols-5">
        <div className="md:col-span-2">
          <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700"><Tractor size={14} /> {lang === "hi" ? "किसानों के लिए" : "For Farmers"}</span>
          <h1 className="mt-3 text-2xl font-bold md:text-3xl">{lang === "hi" ? "अपनी सब्ज़ी हमें बेचें" : "Sell your sabzi to us"}</h1>
          <p className="mt-2 text-gray-600">
            {lang === "hi" ? "आपके पास टमाटर, आलू, भिंडी या कोई भी सब्ज़ी है? अपना भाव खुद तय करें (जैसे 1 कैरेट टमाटर ₹300)। हम आपकी लोकेशन पर आकर देखेंगे, पसंद आई तो वहीं खरीद लेंगे।" : "Have tomatoes, potatoes, bhindi or any sabzi? Set your own price (e.g. 1 crate tomato ₹300). We visit your location, inspect, and buy on the spot if we like it."}
          </p>
          <ul className="mt-5 space-y-3 text-sm">
            {[
              [lang === "hi" ? "अपना भाव खुद डालें" : "You decide the price", IndianRupee],
              [lang === "hi" ? "हम आपके खेत / घर आएंगे" : "We come to your farm / home", MapPin],
              [lang === "hi" ? "तुरंत नकद / UPI पेमेंट" : "Instant cash / UPI payment", CheckCircle2],
            ].map(([txt, Icon]) => {
              const I = Icon as typeof IndianRupee;
              return <li key={txt as string} className="flex items-center gap-2"><span className="grid h-8 w-8 place-items-center rounded-full bg-green-50 text-green-700"><I size={16} /></span>{txt as string}</li>;
            })}
          </ul>
          <a href={`tel:${CONTACT.phone.replace(/\s/g, "")}`} className="mt-6 flex items-center gap-2 text-sm font-semibold text-green-700"><Phone size={16} /> {lang === "hi" ? "या सीधे कॉल करें" : "Or call directly"}: {CONTACT.phone}</a>
        </div>

        <form onSubmit={submit} className="card space-y-3 p-5 md:col-span-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div><label className="label">{lang === "hi" ? "किसान का नाम *" : "Farmer name *"}</label><input required className="input" value={form.farmerName} onChange={(e) => setForm({ ...form, farmerName: e.target.value })} /></div>
            <div><label className="label">{lang === "hi" ? "मोबाइल *" : "Phone *"}</label><input required type="tel" className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="sm:col-span-2"><label className="label">{lang === "hi" ? "गाँव / लोकेशन *" : "Village / Location *"}</label><input required className="input" placeholder="Khutpipariya, Narsinghpur" value={form.village} onChange={(e) => setForm({ ...form, village: e.target.value })} /></div>
            <div><label className="label">{lang === "hi" ? "सब्ज़ी *" : "Vegetable *"}</label><select className="input" value={form.vegetable} onChange={(e) => setForm({ ...form, vegetable: e.target.value })}>{VEGS.map((v) => <option key={v}>{v}</option>)}</select></div>
            <div className="grid grid-cols-2 gap-2">
              <div><label className="label">{lang === "hi" ? "मात्रा *" : "Quantity *"}</label><input required type="number" min={1} className="input" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></div>
              <div><label className="label">{lang === "hi" ? "इकाई" : "Unit"}</label><select className="input" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })}><option value="crate">Crate (कैरेट)</option><option value="kg">Kg</option><option value="quintal">Quintal</option></select></div>
            </div>
            <div><label className="label">{lang === "hi" ? `आपका भाव (₹ प्रति ${form.unit}) *` : `Your price (₹ per ${form.unit}) *`}</label><input required type="number" min={1} className="input" placeholder="300" value={form.expectedPrice} onChange={(e) => setForm({ ...form, expectedPrice: e.target.value })} /></div>
            <label className="flex items-center gap-2 self-end rounded-xl border border-gray-200 px-3 py-2.5 text-sm"><input type="checkbox" className="accent-green-700" checked={form.organic} onChange={(e) => setForm({ ...form, organic: e.target.checked })} /> 🌱 {lang === "hi" ? "ऑर्गेनिक (बिना दवा)" : "Organic (no pesticide)"}</label>
            <div className="sm:col-span-2"><label className="label">{lang === "hi" ? "अन्य जानकारी" : "Notes"}</label><textarea rows={2} className="input" placeholder={lang === "hi" ? "कब तोड़ी, क्वालिटी आदि" : "Harvest date, quality etc."} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          {form.quantity && form.expectedPrice && (
            <p className="rounded-xl bg-green-50 p-3 text-sm text-green-800">
              {lang === "hi" ? "कुल अनुमानित" : "Estimated total"}: <b>₹{Number(form.quantity) * Number(form.expectedPrice)}</b> ({form.quantity} {form.unit} × ₹{form.expectedPrice})
            </p>
          )}
          <button disabled={loading} className="btn-primary w-full py-3"><Tractor size={18} /> {loading ? "..." : lang === "hi" ? "सब्ज़ी लिस्ट करें" : "List my Sabzi"}</button>
        </form>
      </div>
    </div>
  );
}
