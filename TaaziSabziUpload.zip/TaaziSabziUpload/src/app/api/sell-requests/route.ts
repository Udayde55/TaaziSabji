import { NextResponse } from "next/server";
import { db } from "@/db";
import { sellRequests } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(sellRequests).orderBy(desc(sellRequests.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const b = await req.json();
  if (!b.farmerName || !b.phone || !b.vegetable || !b.expectedPrice || !b.quantity)
    return NextResponse.json({ error: "Please fill all required fields" }, { status: 400 });
  const [row] = await db
    .insert(sellRequests)
    .values({
      farmerName: b.farmerName,
      phone: b.phone,
      village: b.village || "Khutpipariya",
      vegetable: b.vegetable,
      quantity: String(b.quantity),
      unit: b.unit || "crate",
      expectedPrice: String(b.expectedPrice),
      organic: !!b.organic,
      notes: b.notes || null,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}

export async function PATCH(req: Request) {
  const b = await req.json();
  const [row] = await db.update(sellRequests).set({ status: b.status }).where(eq(sellRequests.id, Number(b.id))).returning();
  return NextResponse.json(row);
}
