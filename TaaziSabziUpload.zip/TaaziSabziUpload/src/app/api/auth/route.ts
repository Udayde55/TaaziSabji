import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const safe = (u: typeof users.$inferSelect) => ({
  id: u.id,
  name: u.name,
  email: u.email,
  role: u.role as "buyer" | "seller" | "admin",
  phone: u.phone,
  area: u.area,
});

// Simple demo auth (plain credentials). Replace with NextAuth / hashed passwords for real production.
export async function POST(req: Request) {
  await ensureSeeded();
  const body = await req.json();
  const email = String(body.email ?? "").toLowerCase().trim();
  if (body.action === "register") {
    if (!body.name || !email || !body.password)
      return NextResponse.json({ error: "Name, email & password required" }, { status: 400 });
    const [exists] = await db.select().from(users).where(eq(users.email, email));
    if (exists) return NextResponse.json({ error: "Email already registered. Please login." }, { status: 409 });
    const role = ["buyer", "seller"].includes(body.role) ? body.role : "buyer";
    const [u] = await db
      .insert(users)
      .values({ name: body.name, email, phone: body.phone || null, password: body.password, role, area: body.area || null, address: body.address || null })
      .returning();
    return NextResponse.json(safe(u), { status: 201 });
  }
  const [u] = await db.select().from(users).where(eq(users.email, email));
  if (!u || u.password !== body.password) return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
  return NextResponse.json(safe(u));
}

export async function PATCH(req: Request) {
  const body = await req.json();
  if (!body.id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const [u] = await db
    .update(users)
    .set({ name: body.name, phone: body.phone, address: body.address, area: body.area })
    .where(eq(users.id, Number(body.id)))
    .returning();
  return NextResponse.json(safe(u));
}
