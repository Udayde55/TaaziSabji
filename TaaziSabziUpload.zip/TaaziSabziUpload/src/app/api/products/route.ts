import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { getProducts, toDTO } from "@/lib/data";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const list = await getProducts({
    q: searchParams.get("q") ?? undefined,
    category: searchParams.get("category") ?? undefined,
    organic: searchParams.get("organic") === "1",
    seasonal: searchParams.get("seasonal") === "1",
    maxPrice: searchParams.get("maxPrice") ? Number(searchParams.get("maxPrice")) : undefined,
    sort: (searchParams.get("sort") as "popular" | "price_asc" | "price_desc" | "rating" | null) ?? undefined,
  });
  return NextResponse.json(list);
}

export async function POST(req: Request) {
  const body = await req.json();
  if (!body.name || !body.price) return NextResponse.json({ error: "name & price required" }, { status: 400 });
  const slug = `${String(body.name).toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now().toString(36)}`;
  const [row] = await db
    .insert(products)
    .values({
      slug,
      name: body.name,
      nameHi: body.nameHi || body.name,
      variety: body.variety || null,
      description: body.description || null,
      categorySlug: body.categorySlug || "seasonal",
      image: body.image || "/images/tomato.jpg",
      price: String(body.price),
      wholesalePrice: body.wholesalePrice ? String(body.wholesalePrice) : null,
      wholesaleMinQty: body.wholesaleMinQty ? Number(body.wholesaleMinQty) : null,
      unit: body.unit || "kg",
      stock: Number(body.stock ?? 0),
      organic: !!body.organic,
      seasonal: !!body.seasonal,
      freshnessDate: body.freshnessDate || new Date().toISOString().slice(0, 10),
      sellerName: body.sellerName || "TaaziSabzi Farm",
      sellerArea: body.sellerArea || "Khutpipariya, MP",
    })
    .returning();
  return NextResponse.json(toDTO(row), { status: 201 });
}

export async function PATCH(req: Request) {
  const body = await req.json();
  if (!body.id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const patch: Partial<typeof products.$inferInsert> = {};
  if (body.stock !== undefined) patch.stock = Number(body.stock);
  if (body.price !== undefined) patch.price = String(body.price);
  if (body.active !== undefined) patch.active = !!body.active;
  const [row] = await db.update(products).set(patch).where(eq(products.id, Number(body.id))).returning();
  return NextResponse.json(row ? toDTO(row) : null);
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  await db.update(products).set({ active: false }).where(eq(products.id, id));
  return NextResponse.json({ ok: true });
}
