import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, products } from "@/db/schema";
import { COUPONS, deliveryCharge } from "@/lib/data";
import { desc, eq, or, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Item = { id: number; name: string; price: number; qty: number; unit: string; image: string };

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const phone = searchParams.get("phone");
  const email = searchParams.get("email");
  const orderNumber = searchParams.get("orderNumber");
  let rows;
  if (orderNumber) rows = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber));
  else if (phone || email)
    rows = await db
      .select()
      .from(orders)
      .where(or(phone ? eq(orders.phone, phone) : undefined, email ? eq(orders.email, email) : undefined))
      .orderBy(desc(orders.createdAt));
  else rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const items: Item[] = body.items ?? [];
  if (!items.length) return NextResponse.json({ error: "Cart is empty" }, { status: 400 });
  if (!body.customerName || !body.phone || !body.address)
    return NextResponse.json({ error: "Name, phone & address are required" }, { status: 400 });

  // Validate stock and compute server-side prices
  let subtotal = 0;
  const finalItems: Item[] = [];
  for (const it of items) {
    const [p] = await db.select().from(products).where(eq(products.id, it.id));
    if (!p) continue;
    const qty = Math.max(1, Math.min(Number(it.qty), p.stock));
    if (qty <= 0) return NextResponse.json({ error: `${p.name} is out of stock` }, { status: 400 });
    const price = p.wholesalePrice && p.wholesaleMinQty && qty >= p.wholesaleMinQty ? Number(p.wholesalePrice) : Number(p.price);
    subtotal += price * qty;
    finalItems.push({ id: p.id, name: p.name, price, qty, unit: p.unit, image: p.image });
  }

  const slot = body.deliverySlot ?? "sameday";
  const delivery = deliveryCharge(subtotal, slot);
  let discount = 0;
  const coupon = body.coupon ? String(body.coupon).toUpperCase() : null;
  if (coupon && COUPONS[coupon] && subtotal >= COUPONS[coupon].min) {
    const c = COUPONS[coupon];
    discount = c.type === "percent" ? Math.round((subtotal * c.value) / 100) : c.value;
  }
  const total = Math.max(0, subtotal + delivery - discount);
  const orderNumber = `TS${Date.now().toString().slice(-8)}`;
  const paymentMethod = body.paymentMethod ?? "cod";

  const [order] = await db
    .insert(orders)
    .values({
      orderNumber,
      customerName: body.customerName,
      phone: body.phone,
      email: body.email || null,
      address: body.address,
      area: body.area || "Khutpipariya",
      deliverySlot: slot,
      paymentMethod,
      paymentStatus: paymentMethod === "cod" ? "pending" : "paid",
      status: "placed",
      subtotal: String(subtotal),
      deliveryCharge: String(delivery),
      discount: String(discount),
      total: String(total),
      coupon,
      notes: body.notes || null,
      items: finalItems,
    })
    .returning();

  // Decrement stock + increment sold
  for (const it of finalItems) {
    await db
      .update(products)
      .set({ stock: sql`GREATEST(${products.stock} - ${it.qty}, 0)`, sold: sql`${products.sold} + ${it.qty}` })
      .where(eq(products.id, it.id));
  }

  return NextResponse.json(order, { status: 201 });
}

export async function PATCH(req: Request) {
  const body = await req.json();
  if (!body.id || !body.status) return NextResponse.json({ error: "id & status required" }, { status: 400 });
  const [row] = await db
    .update(orders)
    .set({ status: body.status, ...(body.status === "delivered" ? { paymentStatus: "paid" } : {}) })
    .where(eq(orders.id, Number(body.id)))
    .returning();
  return NextResponse.json(row);
}
