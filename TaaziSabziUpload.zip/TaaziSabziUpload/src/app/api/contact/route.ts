import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json();
  if (!b.name || !b.phone || !b.message) return NextResponse.json({ error: "All fields required" }, { status: 400 });
  const [row] = await db.insert(contactMessages).values({ name: b.name, phone: b.phone, message: b.message }).returning();
  return NextResponse.json(row, { status: 201 });
}
