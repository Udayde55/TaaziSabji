import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { avg, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json();
  const rating = Math.max(1, Math.min(5, Number(b.rating)));
  if (!b.productId || !b.name) return NextResponse.json({ error: "productId & name required" }, { status: 400 });
  const [row] = await db
    .insert(reviews)
    .values({ productId: Number(b.productId), name: b.name, rating, comment: b.comment || null })
    .returning();
  const [{ value }] = await db.select({ value: avg(reviews.rating) }).from(reviews).where(eq(reviews.productId, Number(b.productId)));
  if (value) await db.update(products).set({ rating: Number(value).toFixed(1) }).where(eq(products.id, Number(b.productId)));
  return NextResponse.json(row, { status: 201 });
}
