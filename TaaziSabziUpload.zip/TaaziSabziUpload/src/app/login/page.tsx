"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Leaf, LogIn } from "lucide-react";
import { useApp } from "@/store/app";
import { useT } from "@/lib/i18n";
import { toast } from "@/components/ui/Toaster";

export default function LoginPage() {
  const router = useRouter();
  const setUser = useApp((s) => s.setUser);
  const { lang } = useT();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "login", ...form }) });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return toast(data.error, "error");
    setUser(data);
    toast(`${lang === "hi" ? "स्वागत है" : "Welcome"}, ${data.name}!`);
    router.push(data.role === "admin" ? "/admin" : data.role === "seller" ? "/seller" : "/");
  };

  const demo = (email: string, password: string) => setForm({ email, password });

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <div className="card p-6">
        <div className="mb-5 text-center">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-green-700 text-white"><Leaf size={24} /></span>
          <h1 className="mt-3 text-2xl font-bold">{lang === "hi" ? "लॉगिन करें" : "Login"}</h1>
          <p className="text-sm text-gray-500">{lang === "hi" ? "खरीदार, विक्रेता या एडमिन" : "Buyer, Seller or Admin"}</p>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <div><label className="label">Email</label><input required type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div><label className="label">Password</label><input required type="password" className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
          <button disabled={loading} className="btn-primary w-full py-3"><LogIn size={18} /> {loading ? "..." : lang === "hi" ? "लॉगिन" : "Login"}</button>
        </form>
        <p className="mt-4 text-center text-sm text-gray-600">
          {lang === "hi" ? "नया अकाउंट?" : "New here?"} <Link href="/register" className="font-semibold text-green-700">{lang === "hi" ? "रजिस्टर करें" : "Register"}</Link>
        </p>
        <div className="mt-5 rounded-xl bg-green-50 p-3 text-xs text-gray-600">
          <div className="mb-1 font-semibold text-green-800">Demo accounts (tap to fill):</div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => demo("buyer@taazisabzi.in", "buyer123")} className="rounded-lg bg-white px-2 py-1 shadow-sm">Buyer</button>
            <button type="button" onClick={() => demo("seller@taazisabzi.in", "seller123")} className="rounded-lg bg-white px-2 py-1 shadow-sm">Seller</button>
            <button type="button" onClick={() => demo("admin@taazisabzi.in", "admin123")} className="rounded-lg bg-white px-2 py-1 shadow-sm">Admin</button>
          </div>
        </div>
      </div>
    </div>
  );
}
