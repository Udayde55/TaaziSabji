import { Spinner } from "@/components/ui/Common";

export default function Loading() {
  return <Spinner />;
}
