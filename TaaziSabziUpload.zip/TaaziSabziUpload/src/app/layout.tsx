import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Poppins, Noto_Sans_Devanagari } from "next/font/google";
import "./globals.css";
import Header from "@/components/layout/Header";
import BottomNav from "@/components/layout/BottomNav";
import Footer from "@/components/layout/Footer";
import { Toaster } from "@/components/ui/Toaster";

const poppins = Poppins({ subsets: ["latin"], weight: ["400", "500", "600", "700"], variable: "--font-poppins", display: "swap" });
const devanagari = Noto_Sans_Devanagari({ subsets: ["devanagari"], weight: ["400", "500", "600", "700"], variable: "--font-devanagari", display: "swap" });

export const metadata: Metadata = {
  title: "TaaziSabzi – Taazi Sabzi Seedhe Farm Se | Fresh Vegetables Khutpipariya",
  description:
    "Buy & sell farm-fresh vegetables online in Khutpipariya, Madhya Pradesh. Same day delivery, 10-minute express, UPI/COD payments. Farmers can list their sabzi for sale.",
  keywords: ["sabzi", "vegetables", "Khutpipariya", "farm fresh", "online vegetables", "MP"],
  manifest: "/manifest.json",
};

export const viewport: Viewport = { themeColor: "#2E7D32", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${poppins.variable} ${devanagari.variable}`}>
      <body className="font-sans antialiased min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 pb-20 md:pb-0">{children}</main>
        <Footer />
        <BottomNav />
        <Toaster />
      </body>
    </html>
  );
}
