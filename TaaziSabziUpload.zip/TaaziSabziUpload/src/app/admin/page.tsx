import Dashboard from "@/components/dashboard/Dashboard";

export default function AdminPage() {
  return <Dashboard mode="admin" />;
}
