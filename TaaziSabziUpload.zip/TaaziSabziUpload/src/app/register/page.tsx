"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Leaf, UserPlus, ShoppingBasket, Tractor } from "lucide-react";
import { useApp } from "@/store/app";
import { useT } from "@/lib/i18n";
import { toast } from "@/components/ui/Toaster";

export default function RegisterPage() {
  const router = useRouter();
  const setUser = useApp((s) => s.setUser);
  const { lang } = useT();
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", role: "buyer", area: "", address: "" });
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "register", ...form }) });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return toast(data.error, "error");
    setUser(data);
    toast(lang === "hi" ? "अकाउंट बन गया!" : "Account created!");
    router.push(data.role === "seller" ? "/seller" : "/");
  };

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <div className="card p-6">
        <div className="mb-5 text-center">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-green-700 text-white"><Leaf size={24} /></span>
          <h1 className="mt-3 text-2xl font-bold">{lang === "hi" ? "नया अकाउंट बनाएं" : "Create Account"}</h1>
        </div>
        <div className="mb-4 grid grid-cols-2 gap-2">
          {[{ id: "buyer", icon: ShoppingBasket, l: lang === "hi" ? "खरीदार" : "Buyer" }, { id: "seller", icon: Tractor, l: lang === "hi" ? "विक्रेता / किसान" : "Seller / Farmer" }].map(({ id, icon: Icon, l }) => (
            <button type="button" key={id} onClick={() => setForm({ ...form, role: id })} className={`flex items-center justify-center gap-2 rounded-xl border-2 p-3 text-sm font-semibold ${form.role === id ? "border-green-700 bg-green-50 text-green-800" : "border-gray-200"}`}>
              <Icon size={18} /> {l}
            </button>
          ))}
        </div>
        <form onSubmit={submit} className="space-y-3">
          <div><label className="label">{lang === "hi" ? "नाम *" : "Name *"}</label><input required className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="label">Email *</label><input required type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div><label className="label">{lang === "hi" ? "मोबाइल" : "Phone"}</label><input type="tel" className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
          <div><label className="label">{lang === "hi" ? "गाँव / क्षेत्र" : "Village / Area"}</label><input className="input" placeholder="Khutpipariya" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} /></div>
          <div><label className="label">Password *</label><input required minLength={6} type="password" className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
          {form.role === "seller" && <p className="rounded-lg bg-amber-50 p-2 text-xs text-amber-800">{lang === "hi" ? "विक्रेता वेरिफिकेशन: हमारी टीम आपको कॉल करके बेसिक जानकारी कन्फर्म करेगी।" : "Seller verification: our team will call to confirm basic details."}</p>}
          <button disabled={loading} className="btn-primary w-full py-3"><UserPlus size={18} /> {loading ? "..." : lang === "hi" ? "रजिस्टर करें" : "Register"}</button>
        </form>
        <p className="mt-4 text-center text-sm text-gray-600">
          {lang === "hi" ? "पहले से अकाउंट है?" : "Already have an account?"} <Link href="/login" className="font-semibold text-green-700">{lang === "hi" ? "लॉगिन" : "Login"}</Link>
        </p>
      </div>
    </div>
  );
}
