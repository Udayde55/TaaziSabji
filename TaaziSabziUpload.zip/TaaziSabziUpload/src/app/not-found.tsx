import Link from "next/link";
import { EmptyState } from "@/components/ui/Common";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <EmptyState emoji="🥦" title="Page not found" sub="Yeh page hamare khet me nahi uga 🌱" action={<Link href="/" className="btn-primary">Go Home</Link>} />
    </div>
  );
}
