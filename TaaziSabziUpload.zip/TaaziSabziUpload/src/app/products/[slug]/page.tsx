import { notFound } from "next/navigation";
import { getProductBySlug, getProductReviews, getProducts } from "@/lib/data";
import ProductDetail from "@/components/product/ProductDetail";

export const dynamic = "force-dynamic";

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();
  const [reviews, related] = await Promise.all([
    getProductReviews(product.id),
    getProducts({ category: product.categorySlug }),
  ]);
  return (
    <ProductDetail
      p={product}
      reviews={reviews.map((r) => ({ id: r.id, name: r.name, rating: r.rating, comment: r.comment, date: r.createdAt.toISOString().slice(0, 10) }))}
      related={related.filter((r) => r.id !== product.id).slice(0, 4)}
    />
  );
}
