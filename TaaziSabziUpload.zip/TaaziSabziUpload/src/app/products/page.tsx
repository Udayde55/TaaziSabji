import { Suspense } from "react";
import ProductListing from "@/components/product/ProductListing";
import { getCategories } from "@/lib/data";
import { Spinner } from "@/components/ui/Common";

export const dynamic = "force-dynamic";

export default async function ProductsPage() {
  const cats = await getCategories();
  return (
    <Suspense fallback={<Spinner />}>
      <ProductListing cats={cats} />
    </Suspense>
  );
}
