"use client";

import { useState } from "react";
import { Mail, Phone, MapPin, MessageCircle, ShieldCheck, Leaf, RotateCcw, Send } from "lucide-react";
import { useT } from "@/lib/i18n";
import { PageTitle } from "@/components/ui/Common";
import { toast } from "@/components/ui/Toaster";
import { CONTACT } from "@/components/layout/Footer";

export default function ContactPage() {
  const { lang } = useT();
  const [form, setForm] = useState({ name: "", phone: "", message: "" });
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setLoading(false);
    if (res.ok) {
      setForm({ name: "", phone: "", message: "" });
      toast(lang === "hi" ? "संदेश भेजा गया! हम जल्द संपर्क करेंगे" : "Message sent! We'll contact you soon");
    } else toast("Failed", "error");
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <PageTitle title={lang === "hi" ? "संपर्क करें" : "Contact Us"} sub={lang === "hi" ? "कोई सवाल, ऑर्डर या शिकायत? हमें बताएं" : "Questions, orders or complaints? Reach out"} />
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-3">
          <a href={`tel:${CONTACT.phone.replace(/\s/g, "")}`} className="card flex items-center gap-3 p-4 hover:shadow-md"><span className="grid h-10 w-10 place-items-center rounded-full bg-green-50 text-green-700"><Phone size={20} /></span><div><div className="text-xs text-gray-500">{lang === "hi" ? "फ़ोन" : "Phone"}</div><div className="font-semibold">{CONTACT.phone}</div></div></a>
          <a href={`https://wa.me/${CONTACT.phoneRaw}`} target="_blank" rel="noreferrer" className="card flex items-center gap-3 p-4 hover:shadow-md"><span className="grid h-10 w-10 place-items-center rounded-full bg-[#25D366]/10 text-[#25D366]"><MessageCircle size={20} /></span><div><div className="text-xs text-gray-500">WhatsApp</div><div className="font-semibold">{CONTACT.phone}</div></div></a>
          <a href={`mailto:${CONTACT.email}`} className="card flex items-center gap-3 p-4 hover:shadow-md"><span className="grid h-10 w-10 place-items-center rounded-full bg-green-50 text-green-700"><Mail size={20} /></span><div><div className="text-xs text-gray-500">Email</div><div className="font-semibold">{CONTACT.email}</div></div></a>
          <div className="card flex items-center gap-3 p-4"><span className="grid h-10 w-10 place-items-center rounded-full bg-green-50 text-green-700"><MapPin size={20} /></span><div><div className="text-xs text-gray-500">{lang === "hi" ? "पता" : "Address"}</div><div className="font-semibold">{CONTACT.place}</div></div></div>
          <iframe title="map" src="https://www.google.com/maps?q=Khutpipariya,+Madhya+Pradesh&z=12&output=embed" className="card h-56 w-full border-0" loading="lazy" />
        </div>

        <div className="space-y-5">
          <form onSubmit={submit} className="card space-y-3 p-5">
            <h3 className="font-bold">{lang === "hi" ? "संदेश भेजें" : "Send a message"}</h3>
            <input required placeholder={lang === "hi" ? "नाम" : "Name"} className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input required type="tel" placeholder={lang === "hi" ? "मोबाइल" : "Phone"} className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <textarea required rows={4} placeholder={lang === "hi" ? "आपका संदेश / शिकायत" : "Your message / complaint"} className="input" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
            <button disabled={loading} className="btn-primary w-full"><Send size={16} /> {loading ? "..." : lang === "hi" ? "भेजें" : "Send"}</button>
          </form>

          <div id="policy" className="card space-y-4 p-5 text-sm">
            <h3 className="font-bold">{lang === "hi" ? "हमारी नीतियाँ" : "Our Policies"}</h3>
            <div className="flex gap-3"><Leaf className="shrink-0 text-green-700" size={20} /><div><b>{lang === "hi" ? "ताज़गी की गारंटी" : "Freshness Guarantee"}</b><p className="text-gray-600">{lang === "hi" ? "हर सब्ज़ी उसी दिन खेत से तोड़ी जाती है। ताज़ी न हो तो पैसे वापस या बदली।" : "Every vegetable is harvested the same day. Not fresh? Refund or replacement."}</p></div></div>
            <div className="flex gap-3"><RotateCcw className="shrink-0 text-green-700" size={20} /><div><b>{lang === "hi" ? "रिटर्न / रिप्लेसमेंट" : "Return / Replacement"}</b><p className="text-gray-600">{lang === "hi" ? "सब्ज़ी खराब होने वाली चीज़ है, इसलिए डिलीवरी के 2 घंटे के अंदर WhatsApp पर फोटो भेजें। सीमित रिप्लेसमेंट उपलब्ध।" : "Since vegetables are perishable, send a photo on WhatsApp within 2 hours of delivery. Limited replacement available."}</p></div></div>
            <div className="flex gap-3"><ShieldCheck className="shrink-0 text-green-700" size={20} /><div><b>{lang === "hi" ? "सुरक्षित भुगतान" : "Secure Payments"}</b><p className="text-gray-600">{lang === "hi" ? "UPI, कार्ड, नेट बैंकिंग, वॉलेट और COD — सभी भुगतान SSL से सुरक्षित।" : "UPI, cards, net banking, wallet & COD — all payments SSL secured."}</p></div></div>
          </div>
        </div>
      </div>
    </div>
  );
}
