export const STATUS_FLOW = ["placed", "accepted", "packed", "out_for_delivery", "delivered"] as const;

export const STATUS_LABEL: Record<string, { en: string; hi: string; cls: string }> = {
  placed: { en: "Order Placed", hi: "ऑर्डर मिला", cls: "bg-blue-50 text-blue-700" },
  accepted: { en: "Accepted", hi: "स्वीकार", cls: "bg-indigo-50 text-indigo-700" },
  packed: { en: "Packed", hi: "पैक हुआ", cls: "bg-amber-50 text-amber-700" },
  out_for_delivery: { en: "Out for Delivery", hi: "डिलीवरी पर निकला", cls: "bg-orange-50 text-orange-700" },
  delivered: { en: "Delivered", hi: "डिलीवर हुआ", cls: "bg-green-50 text-green-700" },
  cancelled: { en: "Cancelled", hi: "रद्द", cls: "bg-red-50 text-red-700" },
};

export const SLOT_LABEL: Record<string, { en: string; hi: string }> = {
  express10: { en: "10-Min Express", hi: "10 मिनट एक्सप्रेस" },
  sameday: { en: "Same Day (4–8 PM)", hi: "आज ही (शाम 4–8)" },
  nextday: { en: "Next Day (7–10 AM)", hi: "कल सुबह (7–10)" },
};
