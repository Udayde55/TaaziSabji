import { db } from "@/db";
import { categories, orders, products, reviews, sellRequests } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { and, desc, eq, ilike, or, sql } from "drizzle-orm";

export type ProductDTO = {
  id: number;
  slug: string;
  name: string;
  nameHi: string;
  variety: string | null;
  description: string | null;
  categorySlug: string;
  image: string;
  price: number;
  wholesalePrice: number | null;
  wholesaleMinQty: number | null;
  unit: string;
  stock: number;
  organic: boolean;
  seasonal: boolean;
  freshnessDate: string | null;
  sellerName: string;
  sellerArea: string;
  rating: number;
  sold: number;
};

export function toDTO(p: typeof products.$inferSelect): ProductDTO {
  return {
    id: p.id,
    slug: p.slug,
    name: p.name,
    nameHi: p.nameHi,
    variety: p.variety,
    description: p.description,
    categorySlug: p.categorySlug,
    image: p.image,
    price: Number(p.price),
    wholesalePrice: p.wholesalePrice ? Number(p.wholesalePrice) : null,
    wholesaleMinQty: p.wholesaleMinQty,
    unit: p.unit,
    stock: p.stock,
    organic: p.organic,
    seasonal: p.seasonal,
    freshnessDate: p.freshnessDate,
    sellerName: p.sellerName,
    sellerArea: p.sellerArea,
    rating: Number(p.rating),
    sold: p.sold,
  };
}

export async function getCategories() {
  await ensureSeeded();
  return db.select().from(categories).orderBy(categories.id);
}

export type ProductFilters = {
  q?: string;
  category?: string;
  organic?: boolean;
  seasonal?: boolean;
  maxPrice?: number;
  sort?: "popular" | "price_asc" | "price_desc" | "rating";
};

export async function getProducts(f: ProductFilters = {}) {
  await ensureSeeded();
  const conds = [eq(products.active, true)];
  if (f.q) conds.push(or(ilike(products.name, `%${f.q}%`), ilike(products.nameHi, `%${f.q}%`), ilike(products.slug, `%${f.q}%`))!);
  if (f.category && f.category !== "all") {
    if (f.category === "organic") conds.push(eq(products.organic, true));
    else if (f.category === "seasonal") conds.push(eq(products.seasonal, true));
    else conds.push(eq(products.categorySlug, f.category));
  }
  if (f.organic) conds.push(eq(products.organic, true));
  if (f.seasonal) conds.push(eq(products.seasonal, true));
  if (f.maxPrice) conds.push(sql`${products.price} <= ${f.maxPrice}`);

  const order =
    f.sort === "price_asc" ? products.price
    : f.sort === "price_desc" ? desc(products.price)
    : f.sort === "rating" ? desc(products.rating)
    : desc(products.sold);

  const rows = await db.select().from(products).where(and(...conds)).orderBy(order);
  return rows.map(toDTO);
}

export async function getProductBySlug(slug: string) {
  await ensureSeeded();
  const [row] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return row ? toDTO(row) : null;
}

export async function getProductReviews(productId: number) {
  return db.select().from(reviews).where(eq(reviews.productId, productId)).orderBy(desc(reviews.createdAt));
}

export async function getAllOrders() {
  return db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function getAllSellRequests() {
  return db.select().from(sellRequests).orderBy(desc(sellRequests.createdAt));
}

export function deliveryCharge(subtotal: number, slot: string) {
  if (slot === "express10") return 29;
  if (subtotal >= 299) return 0;
  return 19;
}

export const COUPONS: Record<string, { type: "percent" | "flat"; value: number; min: number }> = {
  FRESH10: { type: "percent", value: 10, min: 199 },
  SABZI50: { type: "flat", value: 50, min: 499 },
  WELCOME: { type: "flat", value: 30, min: 149 },
};
