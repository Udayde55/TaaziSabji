"use client";

import { useApp } from "@/store/app";

const dict = {
  en: {
    tagline: "Fresh vegetables straight from the farm",
    heroTitle: "Taazi Sabzi Seedhe Farm Se",
    heroSub: "Farm-fresh vegetables from Khutpipariya farmers, delivered to your door. Same day delivery & 10-minute express available.",
    shopNow: "Shop Now",
    sameDay: "Same Day Delivery",
    sellSabzi: "Sell Your Sabzi",
    searchPlaceholder: "Search tomato, aalu, bhindi...",
    categories: "Categories",
    viewAll: "View all",
    featured: "Fresh Today",
    bestSellers: "Best Sellers",
    seasonalPicks: "Seasonal Picks",
    nearbySellers: "Nearby Farmers & Sellers",
    addToCart: "Add",
    added: "Added",
    farmFresh: "Farm Fresh",
    organic: "Organic",
    lowStock: "Only few left",
    outOfStock: "Out of stock",
    whyUs: "Why TaaziSabzi?",
    home: "Home",
    cart: "Cart",
    orders: "Orders",
    profile: "Profile",
    emptyCart: "Your basket is empty",
    emptyCartSub: "Add some fresh sabzi to get started 🥬",
    checkout: "Checkout",
    subtotal: "Subtotal",
    delivery: "Delivery",
    total: "Total",
    free: "FREE",
    placeOrder: "Place Order",
    login: "Login",
    register: "Register",
    logout: "Logout",
    offersTitle: "Today's Offers",
    deliveryIn10: "Delivery in 10 minutes",
    contact: "Contact Us",
    sell: "Sell",
    wholesale: "Wholesale",
    perUnit: "per",
  },
  hi: {
    tagline: "ताज़ी सब्ज़ी सीधे खेत से",
    heroTitle: "ताज़ी सब्ज़ी सीधे फार्म से",
    heroSub: "खुटपिपरिया के किसानों से ताज़ी सब्ज़ियाँ आपके घर तक। सेम डे डिलीवरी और 10 मिनट एक्सप्रेस उपलब्ध।",
    shopNow: "अभी खरीदें",
    sameDay: "सेम डे डिलीवरी",
    sellSabzi: "अपनी सब्ज़ी बेचें",
    searchPlaceholder: "टमाटर, आलू, भिंडी खोजें...",
    categories: "श्रेणियाँ",
    viewAll: "सभी देखें",
    featured: "आज की ताज़ी",
    bestSellers: "सबसे ज़्यादा बिकने वाली",
    seasonalPicks: "मौसमी सब्ज़ियाँ",
    nearbySellers: "आस-पास के किसान और विक्रेता",
    addToCart: "जोड़ें",
    added: "जोड़ा गया",
    farmFresh: "फार्म फ्रेश",
    organic: "ऑर्गेनिक",
    lowStock: "कुछ ही बचे हैं",
    outOfStock: "स्टॉक खत्म",
    whyUs: "ताज़ीसब्ज़ी क्यों?",
    home: "होम",
    cart: "कार्ट",
    orders: "ऑर्डर",
    profile: "प्रोफ़ाइल",
    emptyCart: "आपकी टोकरी खाली है",
    emptyCartSub: "शुरू करने के लिए ताज़ी सब्ज़ी जोड़ें 🥬",
    checkout: "चेकआउट",
    subtotal: "उप-योग",
    delivery: "डिलीवरी",
    total: "कुल",
    free: "मुफ़्त",
    placeOrder: "ऑर्डर करें",
    login: "लॉगिन",
    register: "रजिस्टर",
    logout: "लॉगआउट",
    offersTitle: "आज के ऑफ़र",
    deliveryIn10: "10 मिनट में डिलीवरी",
    contact: "संपर्क करें",
    sell: "बेचें",
    wholesale: "थोक",
    perUnit: "प्रति",
  },
} as const;

export type TKey = keyof typeof dict.en;

export function useT() {
  const lang = useApp((s) => s.lang);
  const t = (k: TKey) => dict[lang][k];
  return { t, lang };
}

export const unitLabel = (unit: string, lang: "en" | "hi") => {
  const map: Record<string, [string, string]> = {
    kg: ["kg", "किलो"],
    piece: ["pc", "नग"],
    bunch: ["bunch", "गड्डी"],
    crate: ["crate", "कैरेट"],
  };
  return (map[unit] ?? [unit, unit])[lang === "en" ? 0 : 1];
};
